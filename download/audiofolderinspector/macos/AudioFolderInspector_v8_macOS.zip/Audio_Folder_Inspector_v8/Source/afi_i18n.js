/* Audio Folder Inspector i18n v8: canonical message catalog; local-only.
 * Locale-neutral quality codes and complete block messages are translated;
 * legacy Japanese UI strings are normalized before being localized.
 * User-provided file and metadata content is never translated.
 */
(() => {
  'use strict';
  const codeList = ['en','ja','fr','de','es','zh-CN','ko'];
  const languageNames = {en:'English',ja:'日本語',fr:'Français',de:'Deutsch',es:'Español','zh-CN':'简体中文',ko:'한국어'};
  // Legacy Japanese source strings, ordered longest-first at runtime.
  const JA_EN = {
    '音声フォルダ情報 — 品質チェック':'Audio Folder Inspector — Quality Report',
    '音声は再生時のみ読み込み':'Audio loads only when played',
    '解析完了後に表示します。元音声は書き換えません。':'Available after analysis. Original files are never modified.',
    '波形をクリック／ドラッグしてシーク。別ファイルを再生すると、前の音声は停止します。1ページ24件を表示します。':'Click or drag the waveform to seek. Playing a different file stops the previous one. 24 files per page.',
    '左：直下のみ / 右：子フォルダも含む':'Left: direct files / Right: including subfolders',
    'クリックすると全指標を展開':'Click to expand all metrics',
    'このフォルダ直下の音声':'Audio directly in this folder',
    'サブフォルダを含む合計':'Total including subfolders',
    '直下ファイルを一覧で見る':'Show direct files in the table',
    '子フォルダも含めた一覧を見る':'Show files including subfolders',
    'サンプルレート（直下）':'Sample rate (direct)',
    'ビット深度（直下）':'Bit depth (direct)',
    'ビットレート（直下）':'Bit rate (direct)',
    '再生時間 直下/配下':'Duration direct/all',
    '要確認 直下/配下':'Flagged direct/all',
    'ファイル数 直下/配下':'Files direct/all',
    '平均LUFS 直下/配下':'Mean LUFS direct/all',
    '形式（直下）':'Format (direct)',
    '各フォルダの詳細':'Folder details',
    'フォルダ別集計':'Folder summary',
    '全ファイル一覧':'All audio files',
    'ファイル別CSV':'File CSV',
    'フォルダ別CSV':'Folder CSV',
    'デジタル無音ファイル':'Digital silence',
    'LUFS計測不可（短尺またはゲーティング）':'LUFS unavailable (short/gated)',
    '実質無音ファイル':'Effectively silent audio',
    'LUFS指定範囲外':'LUFS outside allowed range',
    'LUFS中央値からの偏差大':'LUFS far from median',
    'True Peak上限超過':'True peak above limit',
    'クリッピング疑い（サンプルピーク）':'Possible clipping (sample peak)',
    'サンプルレート不一致':'Sample rate mismatch',
    'サンプル数不一致':'Sample count mismatch',
    'ビット深度不一致':'Bit depth mismatch',
    'ファイル形式不一致':'Format mismatch',
    'チャンネル数不一致':'Channel count mismatch',
    '冒頭無音が長い':'Long leading silence',
    '末尾無音が長い':'Long trailing silence',
    'DCオフセット大':'High DC offset',
    '左右レベル差大':'Stereo imbalance',
    'ステレオ内Dual Mono':'Dual mono in stereo',
    '読取・デコードエラーのみ':'Read/decode errors only',
    'サブフォルダ含む':'Include subfolders',
    '直下のみ':'Direct only',
    '全フォルダ':'All folders',
    '全ファイル':'All files',
    '要確認のみ':'Flagged only',
    '波形プレーヤー':'Waveform Player',
    '音声ファイルを検索':'Search audio files',
    'ファイル名や値で検索':'Search filenames or values',
    'ファイル名で検索':'Search filenames',
    'ビットレート':'Bit rate',
    'サンプルレート':'Sample rate',
    'ビット深度':'Bit depth',
    'チャンネル数・配置':'Channels / layout',
    'ファイル形式':'File formats',
    '総ファイル容量':'Total file size',
    '総再生時間':'Total duration',
    '中央値 / 標準偏差':'Median / standard deviation',
    '最小 / 最大 LUFS':'Min / max LUFS',
    '平均 LUFS-I':'Mean LUFS-I',
    '最大 True Peak':'Maximum true peak',
    '最大 Sample Peak':'Maximum sample peak',
    '無音 / 実質無音':'Silent / effectively silent',
    '要確認ファイル':'Flagged files',
    'メタデータ検出ファイル':'Files with metadata',
    'メタデータ検出数':'Metadata detected',
    '取得できたファイルの合計':'Total of available durations',
    '取得できた長さの合計':'Total of available durations',
    '解析済みファイル':'Analyzed files',
    '完全な無音 / 閾値以下（無音含む）':'Digital silence / below threshold (including silence)',
    '完全無音 / 閾値以下':'Digital silence / below threshold',
    '問題検出なし':'No issues detected',
    '品質チェック':'Quality checks',
    '平均 LRA':'Mean LRA',
    '有効値のみ':'Valid values only',
    '全ファイルを連結してゲーティングを計算したLUFSと異なります。':'This differs from LUFS measured after concatenating all files.',
    '測定方法と判定基準（クリックで展開）':'Measurement methods and rules (click to expand)',
    'サンプル数':'Sample count',
    '長さ':'Duration',
    '先頭無音秒':'Leading silence (s)',
    '頭無音秒':'Leading silence (s)',
    '末尾無音秒':'Trailing silence (s)',
    'BWF日時':'BWF date/time',
    '差分RMS dB':'Difference RMS dB',
    'コーデック':'Codec',
    'サイズ':'Size',
    'ファイル':'File',
    'フォルダ':'Folder',
    '警告':'Warnings',
    '情報のみ':'Info only', 'エラーのみ':'Errors only',
    '音声ストリームが複数（1本目のみ解析）':'Multiple audio streams (only first analyzed)',
    '読み取り不可':'Unreadable', 'デコードエラー':'Decode error',
    'エラー':'Error', '注意':'Warning', '情報':'Info',
    '状態':'Status',
    '形式':'Format',
    '要確認':'Flagged',
    '読取不可':'Unreadable',
    '解析失敗':'Analysis failed',
    '解析待ち':'Pending',
    '完了まで自動更新します。':'This report updates automatically until complete.',
    '解析中:':'Analyzing:',
    'ファイル':'File',
    '作成:':'Created:',
    '・元音声は変更しません':' · Source files are unchanged',
    '元音声を変更しません。結果はファイルサイズ・更新日時を基準にキャッシュします。':'Source files are never modified. Results are cached by file size and modification time.',
    '表示:':'Showing:',
    '前へ':'Previous',
    '次へ':'Next',
    'BWF / iXML':'BWF / iXML',
    '設定ファイル:':'Configuration:',
    'レポート:':'Report:',
    '不明':'Unknown',
    '有効':'Valid',
    '解析済み':'Analyzed',
    'うち読取／デコード':'Read/decode errors:',
    'うちデコード/読取エラー':'Read/decode errors:',
    'このファイルはプレビューできませんでした':'Could not preview this file',
    '再生サービスがありません。FinderからQuick Actionを再実行してください':'Playback service unavailable. Run the Quick Action again in Finder.',
    '試聴にはQuick Actionを再実行してください':'Run the Quick Action again to preview audio',
    '試聴音声を準備中（初回のみ変換）…':'Preparing audio preview (first play only)…',
    '試聴準備サービスへ接続できません':'Preview service unreachable',
    '変換に失敗しました':'Conversion failed',
    'もう一度 ▶ を押すと再生します':'Press ▶ again to play',
    '再生不可／解析失敗':'Unavailable / analysis failed',
    '再生終了':'Playback ended',
    '条件に一致する音声がありません。':'No audio matches the filters.',
    'クリックしてその位置から再生':'Click to play from this position',
    'シーク位置 ':'Seek position: ',
    '一時停止: ':'Pause: ',
    '再生: ':'Play: ',
    'BWF / iXML':'BWF / iXML',
    '件の算術平均':'-file arithmetic mean',
    '・要確認':' · flagged',
    '・配下':' · incl. subfolders',
    '直下 ':'Direct ',
    '配下 ':'Including subfolders ',
    '時間加重平均 約':'Duration-weighted mean ≈ ',
    '約':'≈',
    '件':' items',
    ' ・ ':' · ',
    '次へ':'Next',
  };
  // Descriptive text nodes split by <strong>, handled as exact translations.
  Object.assign(JA_EN, {
    'Integrated LUFSとLRAはFFmpeg ebur128（EBU R128 / BS.1770）、True Peakはオーバーサンプリング推定、Sample Peak／DC Offset／各ch RMS／サンプル数はastats。サンプルレートやbit深度等はffprobeで取得します。':
      'Integrated LUFS and LRA use FFmpeg ebur128 (EBU R128 / BS.1770). True peak is estimated with oversampling; sample peak, DC offset, per-channel RMS, and sample count use astats. Sample rates and bit depths come from ffprobe.',
    'LUFS平均・標準偏差は':'LUFS mean and standard deviation are computed from the ',
    '有効なファイルごとのIntegrated LUFS':'valid per-file integrated LUFS',
    'の算術平均・標本標準偏差。0.4秒未満の短尺やゲート下限に達した測定結果は無効扱い。これは全ファイルを連結してゲーティングを計算したLUFSと異なります。デジタル無音と読取／デコード失敗は集計から除外。ファイルごとのLRAは別集計で、平均LRAとは異なります。':
      ' (arithmetic mean and sample standard deviation). Files shorter than 0.4 seconds and measurements below the gating threshold are excluded, as are digital silence and read/decode failures. This is not the same as gated LUFS of all audio concatenated. Mean LRA is a separate statistic.',
    'Dual MonoはL-R差分RMSが大きい方のchのRMSより規定値以上小さい場合に検出する近似判定。Sample Peak上限はクリッピング':
      'Dual mono is an approximate detection based on L–R difference RMS relative to the louder channel. A sample peak over the limit is only an indication of ',
    '疑い':'possible clipping',
    'を示すもので、実際のクリッピングを確定するものではありません。頭・末尾の無音は指定dBFS以下が連続する区間で概算します。圧縮形式のサンプル数はデコード後のサンプル数です。BWFタイムリファレンスの時刻表示はサンプル値を音声SRで除算した経過時刻であり、SMPTE時刻やTCレートを保証しません。':
      ', not conclusive proof of actual clipping. Leading/trailing silence is approximated using runs below the selected dBFS threshold. For compressed audio, sample count is decoded samples. The BWF time reference displays elapsed time derived from sample count and sample rate, not necessarily SMPTE timecode.',
    '（JSON、再実行時に反映）。混在チェックは指定値がnullなら':
      ' (JSON; changes take effect on the next scan). When a target format is null, mixed-format checks use the mode of ',
    '選択した全ファイル':'all selected files',
    'の最頻値を基準にします。フォルダ別の要確認件数にも同じ基準を適用します。規格が意図的に混在するフォルダでは警告は参考扱いです。':
      '. The same rule applies to per-folder warning counts; intentionally mixed collections may produce informational warnings.',
    '波形は低解像度の視覚プレビューであり、Sample Peakの精密表示ではありません。再生用のローカルサービスは一定時間操作がないと停止します。その場合はQuick Actionを再実行してください。':
      'Waveforms are low-resolution visual previews, not precision sample-peak graphs. The local playback service exits after inactivity; rerun the Quick Action to listen again.',
    '音声ファイル':'Audio files',
  });
  Object.assign(JA_EN, {
    'フォルダの範囲':'Folder scope',
    '直下ファイル数':'Direct file count',
    '有効値のみ':'Valid measurements only',
    '情報ファイル':'Informational files',
    '完全無音 / 閾値以下':'Digital silence / below threshold',
    '完全な無音 / 閾値以下（無音含む）':'Digital silence / below threshold (including silence)',
    '読取・デコードエラー':'Read / decode errors',
    '作成:':'Created:',
    '・元音声は変更しません':' · Source files are unchanged',
    'このフォルダ直下の音声':'Audio directly in this folder',
    '各ファイルが属する直近のフォルダ':'Immediate parent folder',
    '解析状態':'Analysis state',
    '有効':'Valid',
    '解析済み':'Analyzed',
    'ファイル':'File',
    'フォルダ':'Folder',
    '時間加重平均':'Duration-weighted average',
    'メタデータ検出ファイル':'Files with metadata',
    'クリッピング疑い':'Possible clipping',
  });
  const OTHER = {
    fr: {
      'Warning':'Attention','Info':'Information','Error':'Erreur','Info only':'Informations uniquement','Errors only':'Erreurs uniquement',
      'Audio Folder Inspector — Quality Report':'Inspecteur audio — Rapport qualité', 'Waveform Player':'Lecteur de formes d’onde',
      'Audio files':'Fichiers audio', 'All audio files':'Tous les fichiers audio', 'Quality checks':'Contrôles qualité',
      'Folder summary':'Résumé par dossier', 'Folder details':'Détails des dossiers', 'All folders':'Tous les dossiers',
      'All files':'Tous les fichiers', 'Flagged only':'À vérifier', 'Flagged files':'Fichiers à vérifier',
      'Include subfolders':'Inclure les sous-dossiers', 'Direct only':'Dossier courant',
      'Mean LUFS-I':'LUFS-I moyen', 'Median / standard deviation':'Médiane / écart-type',
      'Min / max LUFS':'LUFS min / max', 'Maximum true peak':'Crête vraie maximale',
      'Maximum sample peak':'Crête échantillon max.', 'Total duration':'Durée totale', 'Total file size':'Taille totale',
      'File formats':'Formats', 'Codec':'Codec', 'Sample rate':'Fréquence d’échantillonnage',
      'Bit depth':'Profondeur de bits', 'Bit rate':'Débit binaire', 'Channels / layout':'Canaux / disposition',
      'Silent / effectively silent':'Silence / quasi-silence', 'Mean LRA':'LRA moyenne',
      'No issues detected':'Aucun problème détecté', 'Status':'État', 'Warnings':'Alertes', 'Duration':'Durée',
      'Format':'Format', 'Size':'Taille', 'Sample count':'Nombre d’échantillons',
      'File':'Fichier', 'Folder':'Dossier', 'File CSV':'CSV fichiers', 'Folder CSV':'CSV dossiers',
      'Previous':'Précédent', 'Next':'Suivant', 'Search filenames':'Rechercher un nom',
      'Search filenames or values':'Rechercher un fichier ou une valeur', 'Search audio files':'Rechercher des fichiers audio',
      'Flagged':'À vérifier', 'Analyzed':'Analysés', 'Valid':'Valides', 'Unknown':'Inconnu',
      'Measurement methods and rules (click to expand)':'Méthodes de mesure et règles (cliquer pour ouvrir)',
      'Audio loads only when played':'Audio chargé uniquement à la lecture',
      'Direct only':'Fichiers directs', 'Total including subfolders':'Total avec sous-dossiers',
      'Show direct files in the table':'Afficher les fichiers directs', 'Show files including subfolders':'Afficher aussi les sous-dossiers',
      'No audio matches the filters.':'Aucun audio ne correspond aux filtres.',
      'Play: ':'Lire : ', 'Pause: ':'Pause : ', 'Seek position: ':'Position : ',
      'Playback ended':'Lecture terminée', 'Preparing audio preview (first play only)…':'Préparation de l’aperçu audio…',
      'Possible clipping (sample peak)':'Écrêtage possible', 'Digital silence':'Silence numérique',
    },
    de: {
      'Warning':'Hinweis','Info':'Info','Error':'Fehler','Info only':'Nur Infos','Errors only':'Nur Fehler',
      'Audio Folder Inspector — Quality Report':'Audio-Ordnerprüfung — Qualitätsbericht','Waveform Player':'Wellenform-Player',
      'Audio files':'Audiodateien','All audio files':'Alle Audiodateien','Quality checks':'Qualitätsprüfung',
      'Folder summary':'Ordnerübersicht','Folder details':'Ordnerdetails','All folders':'Alle Ordner','All files':'Alle Dateien',
      'Flagged only':'Nur Auffällige','Flagged files':'Auffällige Dateien','Include subfolders':'Mit Unterordnern','Direct only':'Nur direkt',
      'Mean LUFS-I':'Mittlere LUFS-I','Median / standard deviation':'Median / Standardabweichung',
      'Min / max LUFS':'LUFS Min. / Max.','Maximum true peak':'Maximaler True Peak','Maximum sample peak':'Maximaler Sample Peak',
      'Total duration':'Gesamtdauer','Total file size':'Gesamtgröße','File formats':'Dateiformate',
      'Sample rate':'Abtastrate','Bit depth':'Bittiefe','Bit rate':'Bitrate','Channels / layout':'Kanäle / Layout',
      'Silent / effectively silent':'Stille / nahezu still','Mean LRA':'Mittlere LRA','No issues detected':'Keine Probleme erkannt',
      'Status':'Status','Warnings':'Warnungen','Duration':'Dauer','Format':'Format','Size':'Größe',
      'Sample count':'Sample-Anzahl','File':'Datei','Folder':'Ordner','File CSV':'Datei-CSV','Folder CSV':'Ordner-CSV',
      'Previous':'Zurück','Next':'Weiter','Search filenames':'Dateinamen suchen','Search filenames or values':'Datei oder Wert suchen',
      'Search audio files':'Audiodateien suchen','Flagged':'Auffällig','Analyzed':'Analysiert','Valid':'Gültig','Unknown':'Unbekannt',
      'Measurement methods and rules (click to expand)':'Messmethoden und Regeln (zum Öffnen klicken)',
      'Audio loads only when played':'Audio wird erst bei Wiedergabe geladen',
      'No audio matches the filters.':'Keine passenden Audiodateien.',
      'Play: ':'Abspielen: ','Pause: ':'Pause: ','Seek position: ':'Suchposition: ',
      'Playback ended':'Wiedergabe beendet','Possible clipping (sample peak)':'Mögliches Clipping',
      'Digital silence':'Digitale Stille',
    },
    es: {
      'Warning':'Aviso','Info':'Información','Error':'Error','Info only':'Solo información','Errors only':'Solo errores',
      'Audio Folder Inspector — Quality Report':'Inspector de audio — Informe de calidad','Waveform Player':'Reproductor de forma de onda',
      'Audio files':'Archivos de audio','All audio files':'Todos los archivos','Quality checks':'Control de calidad',
      'Folder summary':'Resumen por carpeta','Folder details':'Detalles por carpeta','All folders':'Todas las carpetas',
      'All files':'Todos','Flagged only':'Solo alertas','Flagged files':'Archivos con alertas',
      'Include subfolders':'Incluir subcarpetas','Direct only':'Solo esta carpeta','Mean LUFS-I':'LUFS-I medio',
      'Median / standard deviation':'Mediana / desviación estándar','Min / max LUFS':'LUFS mín / máx',
      'Maximum true peak':'Pico real máximo','Maximum sample peak':'Pico de muestra máximo',
      'Total duration':'Duración total','Total file size':'Tamaño total','File formats':'Formatos',
      'Sample rate':'Frecuencia de muestreo','Bit depth':'Profundidad de bits','Bit rate':'Tasa de bits',
      'Channels / layout':'Canales / disposición','Silent / effectively silent':'Silencio / casi silencio',
      'Mean LRA':'LRA medio','No issues detected':'Sin problemas detectados',
      'Status':'Estado','Warnings':'Avisos','Duration':'Duración','Format':'Formato','Size':'Tamaño',
      'Sample count':'Número de muestras','File':'Archivo','Folder':'Carpeta','File CSV':'CSV de archivos',
      'Folder CSV':'CSV de carpetas','Previous':'Anterior','Next':'Siguiente','Search filenames':'Buscar nombre',
      'Search filenames or values':'Buscar archivo o valor','Search audio files':'Buscar audio',
      'Flagged':'Con alerta','Analyzed':'Analizados','Valid':'Válidos','Unknown':'Desconocido',
      'Measurement methods and rules (click to expand)':'Métodos de medición y reglas (abrir)',
      'Audio loads only when played':'Audio cargado solo al reproducir',
      'No audio matches the filters.':'No hay audio que coincida con los filtros.',
      'Play: ':'Reproducir: ','Pause: ':'Pausar: ','Seek position: ':'Posición: ',
      'Playback ended':'Reproducción finalizada','Possible clipping (sample peak)':'Posible saturación',
      'Digital silence':'Silencio digital',
    },
    'zh-CN': {
      'Warning':'注意','Info':'信息','Error':'错误','Info only':'仅信息','Errors only':'仅错误',
      'Audio Folder Inspector — Quality Report':'音频文件夹检查 — 质量报告','Waveform Player':'波形播放器',
      'Audio files':'音频文件','All audio files':'所有音频文件','Quality checks':'质量检查',
      'Folder summary':'文件夹汇总','Folder details':'文件夹详情','All folders':'所有文件夹','All files':'全部文件',
      'Flagged only':'仅显示异常','Flagged files':'异常文件','Include subfolders':'包含子文件夹','Direct only':'仅当前层级',
      'Mean LUFS-I':'平均 LUFS-I','Median / standard deviation':'中位数 / 标准差','Min / max LUFS':'最低 / 最高 LUFS',
      'Maximum true peak':'最大真峰值','Maximum sample peak':'最大采样峰值','Total duration':'总时长',
      'Total file size':'总文件大小','File formats':'文件格式','Sample rate':'采样率','Bit depth':'位深度',
      'Bit rate':'比特率','Channels / layout':'声道数 / 布局','Silent / effectively silent':'无声 / 近似无声',
      'Mean LRA':'平均 LRA','No issues detected':'未检测到异常','Status':'状态','Warnings':'警告',
      'Duration':'时长','Format':'格式','Size':'大小','Sample count':'采样数','File':'文件','Folder':'文件夹',
      'File CSV':'文件 CSV','Folder CSV':'文件夹 CSV','Previous':'上一页','Next':'下一页',
      'Search filenames':'搜索文件名','Search filenames or values':'搜索文件名或数值',
      'Search audio files':'搜索音频文件','Flagged':'异常','Analyzed':'已分析','Valid':'有效','Unknown':'未知',
      'Measurement methods and rules (click to expand)':'测量方法与规则（点击展开）',
      'Audio loads only when played':'音频仅在播放时加载',
      'No audio matches the filters.':'没有符合筛选条件的音频。',
      'Play: ':'播放：','Pause: ':'暂停：','Seek position: ':'跳转位置：',
      'Playback ended':'播放结束','Possible clipping (sample peak)':'疑似削波','Digital silence':'数字静音',
    },
    ko: {
      'Warning':'주의','Info':'정보','Error':'오류','Info only':'정보만','Errors only':'오류만',
      'Audio Folder Inspector — Quality Report':'오디오 폴더 검사 — 품질 보고서','Waveform Player':'파형 플레이어',
      'Audio files':'오디오 파일','All audio files':'전체 오디오 파일','Quality checks':'품질 검사',
      'Folder summary':'폴더별 요약','Folder details':'폴더 상세','All folders':'모든 폴더','All files':'전체 파일',
      'Flagged only':'문제 파일만','Flagged files':'확인 필요 파일','Include subfolders':'하위 폴더 포함','Direct only':'현재 폴더만',
      'Mean LUFS-I':'평균 LUFS-I','Median / standard deviation':'중앙값 / 표준편차','Min / max LUFS':'최소 / 최대 LUFS',
      'Maximum true peak':'최대 트루 피크','Maximum sample peak':'최대 샘플 피크','Total duration':'총 재생 시간',
      'Total file size':'총 파일 크기','File formats':'파일 형식','Sample rate':'샘플 레이트','Bit depth':'비트 깊이',
      'Bit rate':'비트레이트','Channels / layout':'채널 / 배치','Silent / effectively silent':'무음 / 사실상 무음',
      'Mean LRA':'평균 LRA','No issues detected':'문제 없음','Status':'상태','Warnings':'경고',
      'Duration':'재생 시간','Format':'형식','Size':'크기','Sample count':'샘플 수','File':'파일','Folder':'폴더',
      'File CSV':'파일별 CSV','Folder CSV':'폴더별 CSV','Previous':'이전','Next':'다음',
      'Search filenames':'파일명 검색','Search filenames or values':'파일명 또는 값 검색','Search audio files':'오디오 파일 검색',
      'Flagged':'확인 필요','Analyzed':'분석 완료','Valid':'유효','Unknown':'알 수 없음',
      'Measurement methods and rules (click to expand)':'측정 방법 및 기준 (펼치기)',
      'Audio loads only when played':'재생 시에만 오디오 로드',
      'No audio matches the filters.':'필터에 맞는 오디오가 없습니다.',
      'Play: ':'재생: ','Pause: ':'일시정지: ','Seek position: ':'탐색 위치: ',
      'Playback ended':'재생 종료','Possible clipping (sample peak)':'클리핑 의심','Digital silence':'디지털 무음',
    }
  };
  // New UI strings for status/metadata, folder statistics and detailed diagnostics.
  // The descriptive reports below are translated as whole semantic messages,
  // rather than fragments split on <strong> tags.
  const EXTRA = {
    fr: {
      'Folder scope':'Portée du dossier', 'Direct file count':'Fichiers directs',
      'Valid measurements only':'Mesures valides seulement',
      'Informational files':'Fichiers informatifs',
      'Digital silence / below threshold':'Silence numérique / sous le seuil',
      'Digital silence / below threshold (including silence)':'Silence numérique / sous le seuil (silence inclus)',
      'Read / decode errors':'Erreurs de lecture / décodage',
      'Created:':'Créé :',' · Source files are unchanged':' · Fichiers source inchangés',
      'Audio directly in this folder':'Audio directement dans ce dossier',
      'Immediate parent folder':'Dossier parent immédiat','Analysis state':'État de l’analyse',
      'Duration-weighted average':'Moyenne pondérée par la durée','Files with metadata':'Fichiers avec métadonnées',
      'Possible clipping':'Écrêtage possible','Analyzed':'Analysés',
      'Mean LRA':'LRA moyenne','Maximum sample peak':'Pic échantillon maximum',
      'Maximum true peak':'Pic réel maximum','Sample rate mismatch':'Fréquence d’échantillonnage différente',
      'Sample count mismatch':'Nombre d’échantillons différent','Bit depth mismatch':'Profondeur de bits différente',
      'Format mismatch':'Format différent','Channel count mismatch':'Nombre de canaux différent',
      'LUFS unavailable (short/gated)':'LUFS indisponible (court / filtré)',
      'Effectively silent audio':'Audio quasi silencieux','LUFS outside allowed range':'LUFS hors plage autorisée',
      'LUFS far from median':'LUFS éloigné de la médiane','True peak above limit':'Pic réel au-dessus de la limite',
      'Possible clipping (sample peak)':'Écrêtage possible (pic échantillon)',
      'Long leading silence':'Silence initial trop long','Long trailing silence':'Silence final trop long',
      'High DC offset':'Décalage DC élevé','Stereo imbalance':'Déséquilibre stéréo',
      'Dual mono in stereo':'Double mono en stéréo',
      'Multiple audio streams (only first analyzed)':'Plusieurs pistes audio (seule la première analysée)',
      'Unreadable':'Illisible','Decode error':'Erreur de décodage','Analysis failed':'Échec de l’analyse',
      'Pending':'En attente','Files with metadata':'Fichiers avec métadonnées',
      'Total of available durations':'Somme des durées disponibles',
      'Total including subfolders':'Total avec sous-dossiers',
      'Click to expand all metrics':'Cliquer pour développer toutes les mesures',
      'Left: direct files / Right: including subfolders':'À gauche : directs / à droite : avec sous-dossiers',
      'File count direct/all':'Nombre direct / total','Files direct/all':'Fichiers directs / total',
      'Mean LUFS direct/all':'LUFS moyens directs / total','Sample rate (direct)':'Fréquence (direct)',
      'Format (direct)':'Format (direct)','Bit depth (direct)':'Bits (direct)',
      'Bit rate (direct)':'Débit (direct)','Duration direct/all':'Durée directe / totale',
      'Flagged direct/all':'Alertes directes / total',
      'No issues detected':'Aucune anomalie détectée','Valid values only':'Valeurs valides uniquement',
      'Metadata detected':'Métadonnées détectées','Files with metadata':'Fichiers avec métadonnées',
      'Files with metadata':'Fichiers avec métadonnées',
      'Read/decode errors only':'Erreurs de lecture / décodage uniquement',
      'Digital silence / below threshold (including silence)':'Silence numérique / sous le seuil (silence inclus)',
      'Click or drag the waveform to seek. Playing a different file stops the previous one. 24 files per page.':'Cliquer ou faire glisser la forme d’onde pour naviguer. Jouer un autre fichier arrête le précédent. 24 fichiers par page.',
      'Available after analysis. Original files are never modified.':'Disponible après analyse. Les fichiers source restent inchangés.',
      'This report updates automatically until complete.':'Actualisation automatique jusqu’à la fin.',
      'Could not preview this file':'Aperçu impossible',
      'Playback service unavailable. Run the Quick Action again in Finder.':'Service de lecture indisponible. Relancer l’action rapide dans Finder.',
      'Run the Quick Action again to preview audio':'Relancer l’action rapide pour écouter',
      'Preview service unreachable':'Service d’aperçu inaccessible',
      'Conversion failed':'Échec de la conversion','Press ▶ again to play':'Appuyer à nouveau sur ▶ pour lire',
      'Unavailable / analysis failed':'Indisponible / échec de l’analyse',
      'Click to play from this position':'Cliquer pour lire à cette position',
      'Leading silence (s)':'Silence initial (s)','Trailing silence (s)':'Silence final (s)',
      'BWF date/time':'Date / heure BWF','Difference RMS dB':'Différence RMS (dB)',
      'Report:':'Rapport :','Folder CSV:':'CSV dossiers :','Configuration:':'Configuration :',
      'Audio loads only when played':'Audio chargé uniquement à la lecture',
      'Unknown':'Inconnu','Valid':'Valide',
    },
    de: {
      'Folder scope':'Ordnerbereich','Direct file count':'Direkte Dateien','Valid measurements only':'Nur gültige Messwerte',
      'Informational files':'Infodateien','Digital silence / below threshold':'Digitale Stille / unter Schwellwert',
      'Digital silence / below threshold (including silence)':'Digitale Stille / unter Schwellwert (inklusive Stille)',
      'Read / decode errors':'Lese- / Dekodierfehler','Created:':'Erstellt:',' · Source files are unchanged':' · Quelldateien unverändert',
      'Audio directly in this folder':'Audio direkt in diesem Ordner','Immediate parent folder':'Direkter übergeordneter Ordner',
      'Analysis state':'Analysezustand','Duration-weighted average':'Dauergewichteter Mittelwert',
      'Files with metadata':'Dateien mit Metadaten','Possible clipping':'Mögliches Clipping',
      'Sample rate mismatch':'Abtastrate stimmt nicht überein','Sample count mismatch':'Abweichende Sample-Anzahl',
      'Bit depth mismatch':'Abweichende Bittiefe','Format mismatch':'Abweichendes Format',
      'Channel count mismatch':'Abweichende Kanalanzahl','LUFS unavailable (short/gated)':'LUFS nicht messbar (kurz / gegatet)',
      'Effectively silent audio':'Nahezu stummes Audio','LUFS outside allowed range':'LUFS außerhalb des Sollbereichs',
      'LUFS far from median':'LUFS weit vom Median entfernt','True peak above limit':'True Peak über Grenzwert',
      'Possible clipping (sample peak)':'Mögliches Clipping (Sample Peak)',
      'Long leading silence':'Zu lange Stille am Anfang','Long trailing silence':'Zu lange Stille am Ende',
      'High DC offset':'Hoher DC-Offset','Stereo imbalance':'Stereo-Ungleichgewicht',
      'Dual mono in stereo':'Dual Mono im Stereosignal',
      'Multiple audio streams (only first analyzed)':'Mehrere Audiospuren (nur die erste analysiert)',
      'Unreadable':'Nicht lesbar','Decode error':'Dekodierfehler','Analysis failed':'Analyse fehlgeschlagen',
      'Pending':'Ausstehend','Total of available durations':'Summe verfügbarer Laufzeiten',
      'Total including subfolders':'Summe mit Unterordnern','Click to expand all metrics':'Zum Anzeigen aller Kennzahlen klicken',
      'Left: direct files / Right: including subfolders':'Links: direkt / rechts: inklusive Unterordner',
      'Files direct/all':'Dateien direkt / gesamt','Mean LUFS direct/all':'LUFS-Mittel direkt / gesamt',
      'Sample rate (direct)':'Abtastrate (direkt)','Format (direct)':'Format (direkt)',
      'Bit depth (direct)':'Bittiefe (direkt)','Bit rate (direct)':'Bitrate (direkt)',
      'Duration direct/all':'Dauer direkt / gesamt','Flagged direct/all':'Auffälligkeiten direkt / gesamt',
      'Valid values only':'Nur gültige Werte','Metadata detected':'Metadaten erkannt',
      'Read/decode errors only':'Nur Lese- / Dekodierfehler',
      'Click or drag the waveform to seek. Playing a different file stops the previous one. 24 files per page.':'Wellenform anklicken oder ziehen zum Springen. Ein anderes Audio stoppt das vorige. 24 Dateien pro Seite.',
      'Available after analysis. Original files are never modified.':'Nach der Analyse verfügbar. Quelldateien werden nicht geändert.',
      'This report updates automatically until complete.':'Dieser Bericht wird bis zum Abschluss automatisch aktualisiert.',
      'Could not preview this file':'Vorschau nicht möglich',
      'Playback service unavailable. Run the Quick Action again in Finder.':'Wiedergabedienst nicht verfügbar. Quick Action im Finder erneut starten.',
      'Run the Quick Action again to preview audio':'Quick Action für eine Vorschau erneut starten',
      'Preview service unreachable':'Vorschaudienst nicht erreichbar','Conversion failed':'Konvertierung fehlgeschlagen',
      'Press ▶ again to play':'▶ erneut drücken, um abzuspielen',
      'Unavailable / analysis failed':'Nicht verfügbar / Analyse fehlgeschlagen',
      'Click to play from this position':'Klicken, um ab hier abzuspielen',
      'Leading silence (s)':'Stille am Anfang (s)','Trailing silence (s)':'Stille am Ende (s)',
      'BWF date/time':'BWF-Datum / Uhrzeit','Difference RMS dB':'Differenz RMS dB',
      'Report:':'Bericht:','Folder CSV:':'Ordner-CSV:','Configuration:':'Konfiguration:',
      'Unknown':'Unbekannt','Valid':'Gültig',
    },
    es: {
      'Folder scope':'Ámbito de carpeta','Direct file count':'Archivos directos','Valid measurements only':'Solo medidas válidas',
      'Informational files':'Archivos informativos','Digital silence / below threshold':'Silencio digital / bajo umbral',
      'Digital silence / below threshold (including silence)':'Silencio digital / bajo umbral (incluye silencio)',
      'Read / decode errors':'Errores de lectura / decodificación','Created:':'Creado:',' · Source files are unchanged':' · Archivos originales intactos',
      'Audio directly in this folder':'Audio directamente en esta carpeta','Immediate parent folder':'Carpeta principal inmediata',
      'Analysis state':'Estado del análisis','Duration-weighted average':'Promedio ponderado por duración',
      'Files with metadata':'Archivos con metadatos','Possible clipping':'Posible saturación',
      'Sample rate mismatch':'Frecuencia de muestreo diferente','Sample count mismatch':'Número de muestras diferente',
      'Bit depth mismatch':'Profundidad de bits diferente','Format mismatch':'Formato diferente',
      'Channel count mismatch':'Número de canales diferente','LUFS unavailable (short/gated)':'LUFS no disponible (corto / con compuerta)',
      'Effectively silent audio':'Audio prácticamente silencioso','LUFS outside allowed range':'LUFS fuera de rango',
      'LUFS far from median':'LUFS lejos de la mediana','True peak above limit':'Pico real por encima del límite',
      'Possible clipping (sample peak)':'Posible saturación (pico de muestra)',
      'Long leading silence':'Silencio inicial prolongado','Long trailing silence':'Silencio final prolongado',
      'High DC offset':'Desplazamiento DC elevado','Stereo imbalance':'Desequilibrio estéreo',
      'Dual mono in stereo':'Mono dual en estéreo',
      'Multiple audio streams (only first analyzed)':'Varias pistas de audio (solo la primera analizada)',
      'Unreadable':'No se puede leer','Decode error':'Error de decodificación','Analysis failed':'Error de análisis',
      'Pending':'Pendiente','Total of available durations':'Suma de duraciones disponibles',
      'Total including subfolders':'Total con subcarpetas','Click to expand all metrics':'Clic para expandir todas las medidas',
      'Left: direct files / Right: including subfolders':'Izquierda: directos / derecha: con subcarpetas',
      'Files direct/all':'Archivos directos / total','Mean LUFS direct/all':'LUFS medio directo / total',
      'Sample rate (direct)':'Muestreo (directo)','Format (direct)':'Formato (directo)',
      'Bit depth (direct)':'Bits (directo)','Bit rate (direct)':'Tasa de bits (directo)',
      'Duration direct/all':'Duración directa / total','Flagged direct/all':'Alertas directas / total',
      'Valid values only':'Solo valores válidos','Metadata detected':'Metadatos detectados',
      'Read/decode errors only':'Solo errores de lectura / decodificación',
      'Click or drag the waveform to seek. Playing a different file stops the previous one. 24 files per page.':'Haz clic o arrastra la forma de onda para desplazarte. Reproducir otro archivo detiene el anterior. 24 archivos por página.',
      'Available after analysis. Original files are never modified.':'Disponible al terminar el análisis. Los originales no se modifican.',
      'This report updates automatically until complete.':'Este informe se actualiza automáticamente hasta terminar.',
      'Could not preview this file':'No se pudo previsualizar este archivo',
      'Playback service unavailable. Run the Quick Action again in Finder.':'Servicio de reproducción no disponible. Ejecuta otra vez la acción rápida en Finder.',
      'Run the Quick Action again to preview audio':'Vuelve a ejecutar la acción rápida para escuchar',
      'Preview service unreachable':'No se pudo conectar al servicio de vista previa',
      'Conversion failed':'La conversión falló','Press ▶ again to play':'Pulsa ▶ otra vez para reproducir',
      'Unavailable / analysis failed':'No disponible / fallo del análisis',
      'Click to play from this position':'Clic para reproducir desde aquí',
      'Leading silence (s)':'Silencio inicial (s)','Trailing silence (s)':'Silencio final (s)',
      'BWF date/time':'Fecha / hora BWF','Difference RMS dB':'Diferencia RMS dB',
      'Report:':'Informe:','Folder CSV:':'CSV de carpetas:','Configuration:':'Configuración:',
      'Unknown':'Desconocido','Valid':'Válido',
    },
    'zh-CN': {
      'Folder scope':'文件夹范围','Direct file count':'当前文件夹文件数','Valid measurements only':'仅有效测量',
      'Informational files':'信息类文件','Digital silence / below threshold':'数字静音 / 低于阈值',
      'Digital silence / below threshold (including silence)':'数字静音 / 低于阈值（含静音）',
      'Read / decode errors':'读取 / 解码错误','Created:':'创建：',' · Source files are unchanged':' · 原始文件未修改',
      'Audio directly in this folder':'此文件夹中的音频','Immediate parent folder':'直接上级文件夹',
      'Analysis state':'分析状态','Duration-weighted average':'按时长加权平均',
      'Files with metadata':'含元数据的文件','Possible clipping':'疑似削波',
      'Sample rate mismatch':'采样率不一致','Sample count mismatch':'采样数不一致',
      'Bit depth mismatch':'位深不一致','Format mismatch':'格式不一致','Channel count mismatch':'声道数不一致',
      'LUFS unavailable (short/gated)':'无法测量 LUFS（过短或门限过滤）',
      'Effectively silent audio':'近似静音文件','LUFS outside allowed range':'LUFS 超出指定范围',
      'LUFS far from median':'LUFS 偏离中位数','True peak above limit':'真峰值超出限制',
      'Possible clipping (sample peak)':'疑似削波（采样峰值）',
      'Long leading silence':'开头静音过长','Long trailing silence':'结尾静音过长',
      'High DC offset':'直流偏移过大','Stereo imbalance':'左右声道音量差过大',
      'Dual mono in stereo':'立体声中的双单声道',
      'Multiple audio streams (only first analyzed)':'存在多条音轨（仅分析第一条）',
      'Unreadable':'无法读取','Decode error':'解码错误','Analysis failed':'分析失败','Pending':'等待分析',
      'Total of available durations':'已知时长合计','Total including subfolders':'包括子文件夹的总计',
      'Click to expand all metrics':'点击展开所有指标',
      'Left: direct files / Right: including subfolders':'左：仅当前层级 / 右：包含子文件夹',
      'Files direct/all':'当前层级 / 总文件数','Mean LUFS direct/all':'当前层级 / 全部平均 LUFS',
      'Sample rate (direct)':'采样率（当前层级）','Format (direct)':'格式（当前层级）',
      'Bit depth (direct)':'位深（当前层级）','Bit rate (direct)':'比特率（当前层级）',
      'Duration direct/all':'当前层级 / 总时长','Flagged direct/all':'当前层级 / 总异常数',
      'Valid values only':'仅有效值','Metadata detected':'检测到元数据',
      'Read/decode errors only':'仅读取 / 解码错误',
      'Click or drag the waveform to seek. Playing a different file stops the previous one. 24 files per page.':'点击或拖动波形以跳转位置。播放其他文件时停止当前播放。每页显示24个文件。',
      'Available after analysis. Original files are never modified.':'分析完成后显示。不会修改原始文件。',
      'This report updates automatically until complete.':'完成前自动更新此报告。',
      'Could not preview this file':'无法预览此文件',
      'Playback service unavailable. Run the Quick Action again in Finder.':'播放服务不可用。请在 Finder 中重新运行快捷操作。',
      'Run the Quick Action again to preview audio':'请重新运行快捷操作以试听',
      'Preview service unreachable':'无法连接预览服务','Conversion failed':'转换失败',
      'Press ▶ again to play':'再次按 ▶ 播放',
      'Unavailable / analysis failed':'不可播放 / 分析失败',
      'Click to play from this position':'点击从此位置播放',
      'Leading silence (s)':'开头静音（秒）','Trailing silence (s)':'结尾静音（秒）',
      'BWF date/time':'BWF 日期/时间','Difference RMS dB':'差分 RMS dB',
      'Report:':'报告：','Folder CSV:':'文件夹 CSV：','Configuration:':'配置：',
      'Unknown':'未知','Valid':'有效',
    },
    ko: {
      'Folder scope':'폴더 범위','Direct file count':'직속 파일 수','Valid measurements only':'유효 측정값만',
      'Informational files':'정보 파일','Digital silence / below threshold':'디지털 무음 / 임계값 미만',
      'Digital silence / below threshold (including silence)':'디지털 무음 / 임계값 미만 (무음 포함)',
      'Read / decode errors':'읽기 / 디코딩 오류','Created:':'생성:',' · Source files are unchanged':' · 원본 오디오 변경 없음',
      'Audio directly in this folder':'이 폴더에 직접 포함된 오디오','Immediate parent folder':'직접 상위 폴더',
      'Analysis state':'분석 상태','Duration-weighted average':'길이 가중 평균',
      'Files with metadata':'메타데이터 포함 파일','Possible clipping':'클리핑 의심',
      'Sample rate mismatch':'샘플 레이트 불일치','Sample count mismatch':'샘플 수 불일치',
      'Bit depth mismatch':'비트 깊이 불일치','Format mismatch':'파일 형식 불일치',
      'Channel count mismatch':'채널 수 불일치','LUFS unavailable (short/gated)':'LUFS 측정 불가 (짧음 / 게이팅)',
      'Effectively silent audio':'사실상 무음 파일','LUFS outside allowed range':'LUFS 허용 범위 초과',
      'LUFS far from median':'LUFS 중앙값에서 크게 벗어남','True peak above limit':'트루 피크 제한 초과',
      'Possible clipping (sample peak)':'클리핑 의심 (샘플 피크)',
      'Long leading silence':'앞 무음이 너무 김','Long trailing silence':'뒤 무음이 너무 김',
      'High DC offset':'DC 오프셋 과다','Stereo imbalance':'좌우 채널 레벨 차이 과다',
      'Dual mono in stereo':'스테레오 내 듀얼 모노',
      'Multiple audio streams (only first analyzed)':'여러 오디오 스트림 (첫 번째만 분석)',
      'Unreadable':'읽기 불가','Decode error':'디코딩 오류','Analysis failed':'분석 실패','Pending':'분석 대기',
      'Total of available durations':'측정된 길이 합계','Total including subfolders':'하위 폴더 포함 합계',
      'Click to expand all metrics':'클릭하여 모든 지표 펼치기',
      'Left: direct files / Right: including subfolders':'왼쪽: 직속 / 오른쪽: 하위 폴더 포함',
      'Files direct/all':'직속 파일 / 전체 파일','Mean LUFS direct/all':'직속 / 전체 평균 LUFS',
      'Sample rate (direct)':'샘플 레이트 (직속)','Format (direct)':'형식 (직속)',
      'Bit depth (direct)':'비트 깊이 (직속)','Bit rate (direct)':'비트레이트 (직속)',
      'Duration direct/all':'직속 / 전체 길이','Flagged direct/all':'직속 / 전체 확인 필요',
      'Valid values only':'유효한 값만','Metadata detected':'메타데이터 감지',
      'Read/decode errors only':'읽기 / 디코딩 오류만',
      'Click or drag the waveform to seek. Playing a different file stops the previous one. 24 files per page.':'파형을 클릭하거나 드래그하여 탐색합니다. 다른 파일을 재생하면 이전 재생이 중지됩니다. 페이지당 24개 파일.',
      'Available after analysis. Original files are never modified.':'분석 후 표시됩니다. 원본 오디오는 변경하지 않습니다.',
      'This report updates automatically until complete.':'완료될 때까지 보고서를 자동으로 업데이트합니다.',
      'Could not preview this file':'파일 미리보기 실패',
      'Playback service unavailable. Run the Quick Action again in Finder.':'재생 서비스를 사용할 수 없습니다. Finder에서 빠른 동작을 다시 실행하세요.',
      'Run the Quick Action again to preview audio':'미리 들으려면 빠른 동작을 다시 실행하세요',
      'Preview service unreachable':'미리보기 서비스에 연결할 수 없음',
      'Conversion failed':'변환 실패','Press ▶ again to play':'다시 재생하려면 ▶를 누르세요',
      'Unavailable / analysis failed':'재생 불가 / 분석 실패',
      'Click to play from this position':'클릭한 위치부터 재생',
      'Leading silence (s)':'앞 무음 (초)','Trailing silence (s)':'뒤 무음 (초)',
      'BWF date/time':'BWF 날짜 / 시간','Difference RMS dB':'차이 RMS dB',
      'Report:':'보고서:','Folder CSV:':'폴더 CSV:','Configuration:':'설정:',
      'Unknown':'알 수 없음','Valid':'유효',
    },
  };
  for (const lang of Object.keys(EXTRA)) Object.assign(OTHER[lang],EXTRA[lang]);
  const EXTRA_SPLIT = {
    fr:{'Showing:':'Affichage :',' items':' fichiers','items':'fichiers','Files direct/all':'Fichiers directs / total','Quality Report':'Rapport qualité','View':'Affichage'},
    de:{'Showing:':'Angezeigt:',' items':' Dateien','items':'Dateien','Quality Report':'Qualitätsbericht'},
    es:{'Showing:':'Mostrando:',' items':' archivos','items':'archivos','Quality Report':'Informe de calidad'},
    'zh-CN':{'Showing:':'显示：',' items':' 项','items':'项','Quality Report':'质量报告'},
    ko:{'Showing:':'표시:',' items':'건','items':'건','Quality Report':'품질 보고서'}
  };
  for(const lang of Object.keys(EXTRA_SPLIT))Object.assign(OTHER[lang],EXTRA_SPLIT[lang]);

  const TABLE_EXTRA = {
  "fr": {
    "Show direct files in the table": "Afficher les fichiers du dossier",
    "Show files including subfolders": "Afficher avec les sous-dossiers",
    "Format (direct)": "Format (direct)",
    "Format": "Format",
    "Sample Rate": "Fréquence d’échantillonnage",
    "bit depth": "Profondeur de bits",
    "ch / layout": "Canaux / disposition",
    "True Peak": "Pic réel",
    "Sample Peak": "Pic échantillon",
    "L-R RMS dB": "RMS L−R (dB)",
    "Dual Mono": "Double mono",
    "DC Offset %": "Décalage DC (%)",
    "BWF time ref (sample)": "Référence BWF (échantillon)",
    "BWF time ref (time)": "Référence BWF (temps)",
    "BWF Originator": "Créateur BWF",
    "BWF Description": "Description BWF",
    "BWF Originator Reference": "Référence du créateur BWF",
    "iXML Project": "Projet iXML",
    "Scene": "Scène",
    "Take": "Prise",
    "Tape": "Bande",
    "Timecode": "Timecode",
    "Track": "Piste",
    "Note": "Note",
    "Status": "État",
    "Info": "Info",
    "Codec": "Codec",
    "LUFS-I": "LUFS-I",
    "File": "Fichier",
    "Folder": "Dossier"
  },
  "de": {
    "Show direct files in the table": "Direkte Dateien anzeigen",
    "Show files including subfolders": "Auch Unterordner anzeigen",
    "Format (direct)": "Format (direkt)",
    "Format": "Format",
    "Sample Rate": "Abtastrate",
    "bit depth": "Bittiefe",
    "ch / layout": "Kanäle / Layout",
    "True Peak": "True Peak",
    "Sample Peak": "Sample Peak",
    "L-R RMS dB": "L−R RMS dB",
    "Dual Mono": "Dual Mono",
    "DC Offset %": "DC-Offset %",
    "BWF time ref (sample)": "BWF-Zeitreferenz (Samples)",
    "BWF time ref (time)": "BWF-Zeitreferenz (Zeit)",
    "BWF Originator": "BWF-Ersteller",
    "BWF Description": "BWF-Beschreibung",
    "BWF Originator Reference": "BWF-Erstellerreferenz",
    "iXML Project": "iXML-Projekt",
    "Scene": "Szene",
    "Take": "Take",
    "Tape": "Band",
    "Timecode": "Timecode",
    "Track": "Spur",
    "Note": "Notiz",
    "Status": "Status",
    "Info": "Info",
    "Codec": "Codec",
    "LUFS-I": "LUFS-I",
    "File": "Datei",
    "Folder": "Ordner"
  },
  "es": {
    "Show direct files in the table": "Mostrar archivos de esta carpeta",
    "Show files including subfolders": "Mostrar archivos de subcarpetas",
    "Format (direct)": "Formato (directo)",
    "Format": "Formato",
    "Sample Rate": "Frecuencia de muestreo",
    "bit depth": "Profundidad de bits",
    "ch / layout": "Canales / disposición",
    "True Peak": "Pico real",
    "Sample Peak": "Pico de muestra",
    "L-R RMS dB": "RMS L−R (dB)",
    "Dual Mono": "Mono dual",
    "DC Offset %": "Desplazamiento DC %",
    "BWF time ref (sample)": "Referencia BWF (muestras)",
    "BWF time ref (time)": "Referencia BWF (tiempo)",
    "BWF Originator": "Autor BWF",
    "BWF Description": "Descripción BWF",
    "BWF Originator Reference": "Referencia del autor BWF",
    "iXML Project": "Proyecto iXML",
    "Scene": "Escena",
    "Take": "Toma",
    "Tape": "Cinta",
    "Timecode": "Código de tiempo",
    "Track": "Pista",
    "Note": "Nota",
    "Status": "Estado",
    "Info": "Información",
    "Codec": "Códec",
    "LUFS-I": "LUFS-I",
    "File": "Archivo",
    "Folder": "Carpeta"
  },
  "zh-CN": {
    "Show direct files in the table": "查看本文件夹文件",
    "Show files including subfolders": "查看包括子文件夹的文件",
    "Format (direct)": "格式（当前层级）",
    "Format": "格式",
    "Sample Rate": "采样率",
    "bit depth": "位深度",
    "ch / layout": "声道 / 布局",
    "True Peak": "真峰值",
    "Sample Peak": "采样峰值",
    "L-R RMS dB": "左右差分 RMS dB",
    "Dual Mono": "双单声道",
    "DC Offset %": "直流偏移 %",
    "BWF time ref (sample)": "BWF 时间参考（采样）",
    "BWF time ref (time)": "BWF 时间参考（时间）",
    "BWF Originator": "BWF 创建者",
    "BWF Description": "BWF 描述",
    "BWF Originator Reference": "BWF 创建者标识",
    "iXML Project": "iXML 项目",
    "Scene": "场景",
    "Take": "条次",
    "Tape": "磁带",
    "Timecode": "时间码",
    "Track": "轨道",
    "Note": "备注",
    "Status": "状态",
    "Info": "信息",
    "Codec": "编码格式",
    "LUFS-I": "LUFS-I",
    "File": "文件",
    "Folder": "文件夹"
  },
  "ko": {
    "Show direct files in the table": "직속 파일 목록 보기",
    "Show files including subfolders": "하위 폴더까지 목록 보기",
    "Format (direct)": "형식 (직속)",
    "Format": "형식",
    "Sample Rate": "샘플 레이트",
    "bit depth": "비트 깊이",
    "ch / layout": "채널 / 레이아웃",
    "True Peak": "트루 피크",
    "Sample Peak": "샘플 피크",
    "L-R RMS dB": "L−R RMS dB",
    "Dual Mono": "듀얼 모노",
    "DC Offset %": "DC 오프셋 %",
    "BWF time ref (sample)": "BWF 시간 참조 (샘플)",
    "BWF time ref (time)": "BWF 시간 참조 (시간)",
    "BWF Originator": "BWF 제작자",
    "BWF Description": "BWF 설명",
    "BWF Originator Reference": "BWF 제작자 참조",
    "iXML Project": "iXML 프로젝트",
    "Scene": "신",
    "Take": "테이크",
    "Tape": "테이프",
    "Timecode": "타임코드",
    "Track": "트랙",
    "Note": "메모",
    "Status": "상태",
    "Info": "정보",
    "Codec": "코덱",
    "LUFS-I": "LUFS-I",
    "File": "파일",
    "Folder": "폴더"
  }
};
  for(const lang of Object.keys(TABLE_EXTRA))Object.assign(OTHER[lang],TABLE_EXTRA[lang]);
  // Whole-message translations: no mixed-language fragments in descriptions.
  const BLOCKS = {
    en: {
      measurement:'Integrated LUFS and LRA are measured with FFmpeg ebur128 (EBU R128 / ITU-R BS.1770). True peak is estimated with oversampling; sample peak, DC offset, channel RMS and decoded sample count use astats. Sample rates and bit depths are read with ffprobe.',
      lufs_policy:'LUFS mean and standard deviation are calculated from valid per-file integrated LUFS measurements, using arithmetic mean and sample standard deviation. Files shorter than 0.4 s or with insufficient gated loudness are excluded, as are silent files and read/decode failures. Measurable files with warnings or informational findings are included. This differs from integrated LUFS obtained by concatenating the audio. Mean LRA is calculated separately.',
      quality_policy:'Dual mono is an approximate detection from the L–R difference RMS relative to the louder channel. A sample peak at the configured clipping threshold only suggests possible clipping; it does not prove clipped samples. Leading and trailing silence durations are estimated from intervals below the configured dBFS threshold. The sample count for compressed files is measured after decoding. BWF time-reference time is sample count divided by audio sample rate, not necessarily SMPTE timecode.',
      configuration_label:'Configuration:',
      configuration_policy:'(JSON; changes take effect after a new scan.) When an expected_* setting is null, format consistency is compared against the unique most common value among files in the same immediate folder. Ties or fewer than two matching files do not establish an implicit standard. Explicit expected_* settings take precedence in all folders. Dual mono and unavailable short-file LUFS are informational, not flagged.',
      waveform_policy:'Waveforms are low-resolution listening previews, not sample-accurate peak plots. The local audio service exits after a period of inactivity; rerun the Finder Quick Action to listen again.',
      report_label:'Report:', folder_csv_label:'Folder CSV:',
      cache_policy:'Original audio is not modified. Results are cached using file size and modification time.'
    },
    ja: {
      measurement:'Integrated LUFSとLRAはFFmpeg ebur128（EBU R128 / ITU-R BS.1770）で測定します。True Peakはオーバーサンプリングによる推定、Sample Peak・DC Offset・各チャンネルRMS・デコード後のサンプル数はastatsで取得します。サンプルレートやビット深度はffprobeを使用します。',
      lufs_policy:'LUFSの平均・標準偏差は有効なファイルごとのIntegrated LUFSから算術平均・標本標準偏差を計算します。0.4秒未満の短尺、ゲーティングにより測定不能なもの、無音、読み取り・デコード失敗は除外します。注意・情報が付いたファイルでも測定可能なら集計に含めます。全音声を連結したIntegrated LUFSとは異なります。平均LRAは別途算出します。',
      quality_policy:'Dual Monoは、音量の大きいチャンネルに対するL−R差分RMSを使った近似判定です。Sample Peakが設定したしきい値に達してもクリッピングを確定するものではありません。先頭・末尾の無音時間は指定dBFS以下の連続区間から推定します。圧縮形式のサンプル数はデコード後の値です。BWFタイムリファレンスはサンプル数を音声サンプルレートで割った時刻であり、必ずしもSMPTEタイムコードではありません。',
      configuration_label:'設定ファイル:',
      configuration_policy:'（JSON。変更は次回解析時に反映。）expected_* がnullの場合、各ファイルが属する直近のフォルダ内で最頻値を基準に規格を比較します。同数の場合や同じ値が2件未満の場合、暗黙の規格を決めません。明示したexpected_*の指定は全フォルダで優先します。Dual Monoと短尺によるLUFS計測不可は「情報」であり「要確認」に含めません。',
      waveform_policy:'波形は試聴用の低解像度表示であり、Sample Peakの精密表示ではありません。ローカルの再生サービスは一定時間操作がなければ終了します。その場合はFinderのQuick Actionを再実行してください。',
      report_label:'レポート:',folder_csv_label:'フォルダ別CSV:',
      cache_policy:'元音声は変更しません。解析結果はファイルサイズと更新日時を基準にキャッシュします。'
    },
    fr: {
      measurement:'LUFS intégré et LRA sont mesurés avec FFmpeg ebur128 (EBU R128 / ITU-R BS.1770). Le pic réel est estimé par suréchantillonnage ; le pic échantillon, le décalage DC, le RMS par canal et le nombre d’échantillons décodés utilisent astats. La fréquence d’échantillonnage et la profondeur de bits proviennent de ffprobe.',
      lufs_policy:'La moyenne et l’écart-type des LUFS sont calculés à partir des LUFS intégrés valides de chaque fichier. Les fichiers de moins de 0,4 s, ceux exclus par le seuil de mesure, les silences et les erreurs de décodage sont exclus. Les fichiers avec alertes mais mesurables sont inclus. Ce résultat diffère du LUFS intégré des fichiers concaténés. Le LRA moyen est calculé séparément.',
      quality_policy:'La détection du double mono est une approximation basée sur le RMS de la différence L−R rapporté au canal le plus fort. Le seuil de pic échantillon indique un écrêtage possible, sans le confirmer. Les silences en début et fin sont estimés sous le seuil dBFS défini. Le nombre d’échantillons des fichiers compressés est calculé après décodage. La référence temporelle BWF ne garantit pas un timecode SMPTE.',
      configuration_label:'Configuration :',
      configuration_policy:'(JSON ; modifications appliquées à la prochaine analyse.) Si un réglage expected_* vaut null, la valeur majoritaire unique du dossier parent direct sert de référence. En cas d’égalité ou de moins de deux fichiers identiques, aucune norme implicite n’est déduite. Les valeurs expected_* explicites priment pour tous les dossiers. Double mono et LUFS non mesurable sur un fichier court sont informatifs, pas des alertes.',
      waveform_policy:'Les formes d’onde sont des aperçus basse résolution pour l’écoute, et non des tracés précis de crête. Le service local s’arrête après une période d’inactivité ; relancez l’action rapide Finder pour écouter.',
      report_label:'Rapport :',folder_csv_label:'CSV dossiers :',
      cache_policy:'Les fichiers audio originaux ne sont pas modifiés. Le cache repose sur la taille et la date de modification.'
    },
    de: {
      measurement:'Integrated LUFS und LRA werden mit FFmpeg ebur128 (EBU R128 / ITU-R BS.1770) gemessen. True Peak wird durch Oversampling geschätzt; Sample Peak, DC-Offset, Kanal-RMS und dekodierte Sample-Anzahl stammen aus astats. Abtastrate und Bittiefe liest ffprobe.',
      lufs_policy:'LUFS-Mittelwert und Standardabweichung werden aus den gültigen Integrated-LUFS-Werten der einzelnen Dateien berechnet. Dateien unter 0,4 s, nicht messbare gegatete Werte, Stille und Lese-/Dekodierfehler werden ausgeschlossen. Messbare Dateien mit Hinweisen bleiben enthalten. Dies unterscheidet sich vom Integrated LUFS aller aneinandergereihten Dateien. Der mittlere LRA wird separat berechnet.',
      quality_policy:'Dual Mono wird näherungsweise aus dem RMS des L−R-Differenzsignals relativ zum lauteren Kanal erkannt. Ein Sample Peak am Grenzwert deutet nur auf mögliches Clipping hin, beweist es aber nicht. Stille an Anfang und Ende wird anhand des eingestellten dBFS-Schwellwerts geschätzt. Die Sample-Anzahl komprimierter Dateien wird nach dem Dekodieren gemessen. Die BWF-Zeitreferenz ist nicht zwingend SMPTE-Timecode.',
      configuration_label:'Konfiguration:',
      configuration_policy:'(JSON; Änderungen gelten beim nächsten Scan.) Ist expected_* null, gilt der eindeutig häufigste Wert im unmittelbar übergeordneten Ordner als Referenz. Gleichstand oder weniger als zwei gleiche Dateien ergeben keinen impliziten Standard. Explizite expected_*-Werte haben für alle Ordner Vorrang. Dual Mono und nicht messbares LUFS bei Kurzdateien gelten als Information, nicht als Warnung.',
      waveform_policy:'Wellenformen sind grobe Vorschauen zum Anhören, keine samplegenauen Peak-Diagramme. Der lokale Audiodienst beendet sich nach längerer Inaktivität; zum erneuten Hören die Finder-Quick-Action starten.',
      report_label:'Bericht:',folder_csv_label:'Ordner-CSV:',
      cache_policy:'Original-Audiodateien werden nicht geändert. Ergebnisse werden anhand von Dateigröße und Änderungsdatum zwischengespeichert.'
    },
    es: {
      measurement:'LUFS integrado y LRA se miden con FFmpeg ebur128 (EBU R128 / ITU-R BS.1770). El pico real se estima mediante sobremuestreo; pico de muestra, desplazamiento DC, RMS por canal y muestras decodificadas se obtienen con astats. La frecuencia de muestreo y la profundidad de bits provienen de ffprobe.',
      lufs_policy:'La media y desviación estándar de LUFS se calculan a partir de los valores integrados válidos de cada archivo. Se excluyen archivos de menos de 0,4 s, resultados no medibles por la compuerta, silencios y errores de lectura o decodificación. Se incluyen archivos medibles con avisos informativos. Esto difiere del LUFS integrado de todos los archivos concatenados. El LRA medio se calcula por separado.',
      quality_policy:'La detección de mono dual es aproximada y compara el RMS de la diferencia L−R con el canal de mayor nivel. Alcanzar el umbral de pico de muestra solo indica posible saturación. Los silencios inicial y final se estiman con el umbral dBFS configurado. En audio comprimido, las muestras se cuentan después de decodificar. La referencia temporal BWF no equivale necesariamente a un código de tiempo SMPTE.',
      configuration_label:'Configuración:',
      configuration_policy:'(JSON; los cambios se aplican en el siguiente análisis.) Si expected_* es null, se utiliza el valor más común sin empate dentro de la carpeta inmediata. Con empate o menos de dos archivos iguales, no se presupone una norma. Los valores expected_* explícitos prevalecen en todas las carpetas. Mono dual y LUFS no disponible por duración corta son datos informativos, no alertas.',
      waveform_policy:'Las formas de onda son vistas previas de baja resolución, no gráficos exactos de pico de muestra. El servicio local se cierra tras un período de inactividad; vuelve a ejecutar la acción rápida en Finder para escuchar.',
      report_label:'Informe:',folder_csv_label:'CSV de carpetas:',
      cache_policy:'Los audios originales no se modifican. Los resultados se almacenan en caché según el tamaño y fecha de modificación.'
    },
    'zh-CN': {
      measurement:'Integrated LUFS 和 LRA 使用 FFmpeg ebur128（EBU R128 / ITU-R BS.1770）测量。True Peak 通过过采样估算；Sample Peak、直流偏移、各声道 RMS 和解码后采样数通过 astats 获取。采样率及位深由 ffprobe 读取。',
      lufs_policy:'LUFS 平均值和标准差由各文件有效的 Integrated LUFS 计算（算术平均与样本标准差）。低于 0.4 秒、无法通过门限测量、静音或读取/解码失败的文件不纳入统计。可正常测量但带有警告或信息的文件仍计入。此值不同于连接全部音频后测得的 Integrated LUFS。平均 LRA 单独计算。',
      quality_policy:'双单声道检测通过左右差分 RMS 相对于较大声道 RMS 的比例近似判断。采样峰值达到阈值只说明可能削波，并不证明发生削波。首尾静音时长按配置的 dBFS 门限估算。压缩音频的采样数为解码后的样本数。BWF 时间参考不一定对应 SMPTE 时间码。',
      configuration_label:'配置：',
      configuration_policy:'（JSON；修改在下次扫描时生效。）expected_* 为 null 时，以文件所在直接父文件夹中唯一占多数的规格为准。数量相同或相同值少于两个时，不推断默认规格。显式设置的 expected_* 对全部文件夹生效。双单声道和短文件 LUFS 不可测量属于信息，不计入异常。',
      waveform_policy:'波形仅为低分辨率试听预览，不是精确的采样峰值图。长时间不操作时本地播放服务会退出；需要试听时请在 Finder 中重新运行快捷操作。',
      report_label:'报告：',folder_csv_label:'文件夹 CSV：',
      cache_policy:'不会修改原始音频。分析结果根据文件大小和修改时间进行缓存。'
    },
    ko: {
      measurement:'Integrated LUFS와 LRA는 FFmpeg ebur128(EBU R128 / ITU-R BS.1770)로 측정합니다. True Peak는 오버샘플링으로 추정하며, Sample Peak, DC 오프셋, 채널별 RMS, 디코딩한 샘플 수는 astats로 측정합니다. 샘플 레이트와 비트 깊이는 ffprobe로 읽습니다.',
      lufs_policy:'LUFS 평균과 표준편차는 각 파일의 유효한 Integrated LUFS 값으로 계산합니다. 0.4초 미만의 짧은 파일, 게이트로 측정할 수 없는 파일, 무음 및 읽기/디코딩 실패 파일은 제외합니다. 주의나 정보가 있어도 측정 가능한 파일은 포함됩니다. 모든 파일을 연결하여 측정한 Integrated LUFS와는 다릅니다. 평균 LRA는 별도로 계산합니다.',
      quality_policy:'듀얼 모노는 큰 채널의 RMS에 대한 L−R 차이 신호의 RMS를 이용하여 근사적으로 검출합니다. Sample Peak가 설정한 임계값에 도달해도 실제 클리핑이 확정되는 것은 아닙니다. 앞뒤 무음 시간은 설정된 dBFS 임계값 미만의 구간으로 추정합니다. 압축 오디오의 샘플 수는 디코딩 후 측정값입니다. BWF 시간 기준은 반드시 SMPTE 타임코드인 것은 아닙니다.',
      configuration_label:'설정 파일:',
      configuration_policy:'(JSON, 변경 사항은 다음 스캔에 적용됩니다.) expected_*가 null이면 각 파일이 속한 직속 상위 폴더에서 가장 빈번한 유일한 값을 기준으로 비교합니다. 동률이거나 동일한 값이 2개 미만이면 기본 규격을 추정하지 않습니다. 명시적 expected_* 설정은 모든 폴더에서 우선합니다. 듀얼 모노와 짧은 파일의 LUFS 측정 불가는 정보이며 주의 대상에 포함되지 않습니다.',
      waveform_policy:'파형은 시청용 저해상도 미리보기이며 정확한 샘플 피크 그래프가 아닙니다. 일정 시간 사용하지 않으면 로컬 재생 서비스가 종료됩니다. 다시 들으려면 Finder 빠른 동작을 재실행하세요.',
      report_label:'보고서:',folder_csv_label:'폴더 CSV:',
      cache_policy:'원본 오디오는 변경되지 않습니다. 파일 크기와 수정 시간을 기준으로 결과를 캐시합니다.'
    }
  };
  // Canonical Japanese -> English conversion for legacy server-rendered labels.
  const sorted = Object.entries(JA_EN).sort((a,b)=>b[0].length-a[0].length);
  const escapeRegex = txt=>txt.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const phrasePattern = new RegExp(sorted.map(pair=>escapeRegex(pair[0])).join('|'),'g');
  const nodes = new WeakMap(), attributes = new WeakMap();
  const jp = /[\u3040-\u30ff\u3400-\u9fff]/;

  function count(n,lang){
    if(lang==='ja')return n+'件';
    if(lang==='zh-CN')return n+' 项';
    if(lang==='ko')return n+'건';
    if(lang==='de')return n+(Number(String(n).replace(/,/g,''))===1?' Datei':' Dateien');
    if(lang==='fr')return n+(Number(String(n).replace(/,/g,''))===1?' fichier':' fichiers');
    if(lang==='es')return n+(Number(String(n).replace(/,/g,''))===1?' archivo':' archivos');
    return n+' '+(Number(String(n).replace(/,/g,''))===1?'item':'items');
  }
  const dlab = {
    en:{analyzed:'Analyzed',valid:'Valid',arithmetic:'Arithmetic mean of',warning:'Warnings',error:'Errors',info:'Info',direct:'Direct',sub:'Including subfolders',flagged:'Flagged',created:'Created:',unchanged:'Source files are unchanged',weighted:'Duration-weighted average'},
    ja:{analyzed:'解析済み',valid:'有効',arithmetic:'算術平均',warning:'注意',error:'エラー',info:'情報',direct:'直下',sub:'配下',flagged:'要確認',created:'作成:',unchanged:'元音声は変更しません',weighted:'時間加重平均'},
    fr:{analyzed:'Analysés',valid:'Valides',arithmetic:'Moyenne arithmétique de',warning:'Alertes',error:'Erreurs',info:'Infos',direct:'Direct',sub:'Avec sous-dossiers',flagged:'À vérifier',created:'Créé :',unchanged:'Fichiers source inchangés',weighted:'Moyenne pondérée par la durée'},
    de:{analyzed:'Analysiert',valid:'Gültig',arithmetic:'Arithmetisches Mittel aus',warning:'Warnungen',error:'Fehler',info:'Infos',direct:'Direkt',sub:'Mit Unterordnern',flagged:'Auffällig',created:'Erstellt:',unchanged:'Quelldateien unverändert',weighted:'Dauergewichteter Mittelwert'},
    es:{analyzed:'Analizados',valid:'Válidos',arithmetic:'Media aritmética de',warning:'Avisos',error:'Errores',info:'Información',direct:'Directo',sub:'Con subcarpetas',flagged:'Alertas',created:'Creado:',unchanged:'Originales intactos',weighted:'Promedio ponderado por duración'},
    'zh-CN':{analyzed:'已分析',valid:'有效',arithmetic:'算术平均，文件数',warning:'注意',error:'错误',info:'信息',direct:'当前层级',sub:'包含子文件夹',flagged:'异常',created:'创建：',unchanged:'原始文件未修改',weighted:'按时长加权平均'},
    ko:{analyzed:'분석 완료',valid:'유효',arithmetic:'산술 평균 파일 수',warning:'주의',error:'오류',info:'정보',direct:'직속',sub:'하위 폴더 포함',flagged:'확인 필요',created:'생성:',unchanged:'원본 오디오는 변경하지 않음',weighted:'길이 가중 평균'}
  };
  function dynamicString(source,lang){
    const t=String(source).trim();const l=dlab[lang]||dlab.en;
    let m;
    if((m=t.match(/^解析済み\s+([\d,]+)$/)))return l.analyzed+' '+m[1];
    if((m=t.match(/^有効\s+([\d,]+)件$/)))return l.valid+' '+count(m[1],lang);
    if((m=t.match(/^([\d,]+)件の算術平均$/)))return l.arithmetic+' '+count(m[1],lang);
    if((m=t.match(/^注意\s+([\d,]+)件\s*\/\s*エラー\s+([\d,]+)件\s*\/\s*情報\s+([\d,]+)件$/)))
      return `${l.warning} ${count(m[1],lang)} / ${l.error} ${count(m[2],lang)} / ${l.info} ${count(m[3],lang)}`;
    if((m=t.match(/^直下\s+([\d,]+)件\s*・\s*配下\s+([\d,]+)件\s*・\s*要確認\s+([\d,]+)\s*\/\s*([\d,]+)件（情報\s+([\d,]+)件）$/)))
      return `${l.direct} ${count(m[1],lang)} · ${l.sub} ${count(m[2],lang)} · ${l.flagged} ${m[3]} / ${count(m[4],lang)} (${l.info} ${count(m[5],lang)})`;
    if((m=t.match(/^作成:\s*(.*?)・元音声は変更しません$/)))return `${l.created} ${m[1]} · ${l.unchanged}`;
    if((m=t.match(/^([\d,]+)件$/)))return count(m[1],lang);
    if(t==='件')return ({en:' items',ja:'件',fr:' fichiers',de:' Dateien',es:' archivos','zh-CN':'项',ko:'건'})[lang];
    if((m=t.match(/^\/\s*時間加重平均\s*約([\d.]+)\s*kb\/s$/)))return ` / ${l.weighted} ≈${m[1]} kb/s`;
    if((m=t.match(/^(.*?)(\s*\/\s*時間加重平均\s*約([\d.]+)\s*kb\/s)$/)))return `${m[1]} / ${l.weighted} ≈${m[3]} kb/s`;
    return null;
  }
  // Keep filenames/metadata opaque. Do not convert Japanese words in user data.
  function skip(el){
    if(!el)return true;
    if(el.closest('script,style,code,pre,[data-afi-untranslated],[data-afi-i18n-key],.playername,.foldertable tbody td:first-child,.folderdetail summary strong'))return true;
    const td=el.closest('#filebody td');
    if(td){const i=Array.prototype.indexOf.call(td.parentElement.children,td);
      // columns: 0 filename, 20-32 BWF/iXML user metadata; 33 status, 34 reason
      if(i===0 || (i>=20 && i<=32))return true;
    }
    return false;
  }
  const systemLanguage = codeList.includes(window.AFI_SYSTEM_LANGUAGE) ? window.AFI_SYSTEM_LANGUAGE : 'en';
  const allowedModes = ['auto', ...codeList];
  let mode = allowedModes.includes(window.AFI_DEFAULT_LANGUAGE) ? window.AFI_DEFAULT_LANGUAGE : 'auto';
  // New key intentionally avoids migrating v5's default-English preference as
  // if the user had explicitly chosen English in the menu.
  try {
    const stored=localStorage.getItem('afi_ui_locale_v6');
    if(allowedModes.includes(stored))mode=stored;
  } catch (_) {}
  let selected=mode==='auto' ? systemLanguage : mode;
  const autoLabels={en:'Auto (System Language)',ja:'自動（システム言語）',fr:'Auto (langue du système)',de:'Automatisch (Systemsprache)',es:'Automático (idioma del sistema)','zh-CN':'自动（系统语言）',ko:'자동 (시스템 언어)'};
  function toCanonicalEnglish(source){
    return jp.test(source)?String(source).replace(phrasePattern,ja=>JA_EN[ja]):String(source);
  }
  const localePatterns={};
  for(const [lang,dict] of Object.entries(OTHER)){
    const words=Object.keys(dict).sort((a,b)=>b.length-a.length);
    localePatterns[lang]=new RegExp(words.map(escapeRegex).join('|'),'g');
  }
  function translateCanonical(english,lang){
    if(lang==='en'||lang==='ja')return english;
    const dict=OTHER[lang]||{};
    if(Object.prototype.hasOwnProperty.call(dict,english))return dict[english];
    const pattern=localePatterns[lang];
    if(!pattern)return english;
    pattern.lastIndex=0;
    return String(english).replace(pattern,(hit,at,whole)=>{
      const previous=at>0?whole[at-1]:'';const next=whole[at+hit.length]||'';
      if((/[A-Za-z]$/.test(previous)&&/^[A-Za-z]/.test(hit)) ||
         (/[A-Za-z]$/.test(hit)&&/^[A-Za-z]/.test(next)))return hit;
      return dict[hit];
    });
  }
  const EN_UI_TO_JA = {"Sample Rate": "サンプルレート", "bit depth": "ビット深度", "ch / layout": "チャンネル / 配置", "kb/s": "kb/s", "True Peak": "True Peak", "Sample Peak": "Sample Peak", "L-R RMS dB": "L−R RMS dB", "BWF time ref (sample)": "BWFタイムリファレンス（サンプル）", "BWF time ref (time)": "BWFタイムリファレンス（時刻）", "BWF Originator": "BWF作成者", "BWF Description": "BWF説明", "BWF Originator Reference": "BWF作成者参照", "iXML Project": "iXMLプロジェクト", "Scene": "シーン", "Take": "テイク", "Tape": "テープ", "Timecode": "タイムコード", "Track": "トラック", "Note": "備考", "Status": "状態"};
  function translateText(source,lang=selected){
    if(!source)return source;
    if(lang==='ja')return EN_UI_TO_JA[String(source).trim()] ?? source;
    let raw=String(source);
    // Leading/trailing whitespace is meaningful for inline labels around numbers.
    const lead=(raw.match(/^\s*/)||[''])[0],tail=(raw.match(/\s*$/)||[''])[0];
    const middle=raw.substring(lead.length,raw.length-tail.length);
    const dynamic=dynamicString(middle,lang);
    return lead+(dynamic!==null?dynamic:translateCanonical(toCanonicalEnglish(middle),lang))+tail;
  }
  function translateDOM(root=document.body) {
    if(!root)return;
    const walk=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
    while(walk.nextNode()){
      const node=walk.currentNode;
      if(skip(node.parentElement))continue;
      let record=nodes.get(node);
      if(!record || node.nodeValue!==record.rendered){record={source:node.nodeValue,rendered:node.nodeValue};nodes.set(node,record);}
      const target=translateText(record.source,selected);
      record.rendered=target;
      if(target!==node.nodeValue)node.nodeValue=target;
    }
    for(const element of root.querySelectorAll('[title],[placeholder],[aria-label]')){
      if(skip(element))continue;
      if(!attributes.has(element))attributes.set(element,{});
      const old=attributes.get(element);
      for(const attr of ['title','placeholder','aria-label']){
        if(!element.hasAttribute(attr))continue;
        const current=element.getAttribute(attr);
        if(!(attr in old)||old[attr].rendered!==current)old[attr]={source:current,rendered:current};
        const val=translateText(old[attr].source,selected);
        old[attr].rendered=val;
        if(val!==current)element.setAttribute(attr,val);
      }
    }
    // Entire semantic paragraphs are localized by key, avoiding mixed-language
    // sentences when markup splits a paragraph into several text nodes.
    for(const node of document.querySelectorAll('[data-afi-i18n-key]')){
      const key=node.getAttribute('data-afi-i18n-key');
      const value=BLOCKS[selected]?.[key] ?? BLOCKS.en[key];
      if(typeof value==='string' && node.textContent!==value)node.textContent=value;
    }
    document.documentElement.lang=selected;
    const selector=document.getElementById('afiLang');
    if(selector){
      selector.value=mode;
      const autoOption=selector.querySelector('option[value="auto"]');
      if(autoOption)autoOption.textContent=autoLabels[selected]+' — '+languageNames[systemLanguage];
    }
    const label=document.getElementById('afiLangLabel');
    if(label)label.textContent= {en:'Language',ja:'言語',fr:'Langue',de:'Sprache',es:'Idioma','zh-CN':'语言',ko:'언어'}[selected];
    const title=document.querySelector('h1');if(title)document.title=title.textContent;
  }
  function change(lang){
    if(!allowedModes.includes(lang))return;
    mode=lang;
    selected=mode==='auto' ? systemLanguage : mode;
    try{localStorage.setItem('afi_ui_locale_v6',mode);}catch(_){}
    // Persist explicit selection across future Finder reports. If the local
    // report server has expired, the selection still works for this page.
    const base=typeof AFI_BASE==='string' ? AFI_BASE : '';
    if(base) fetch(`${base}/language`,{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({mode}),cache:'no-store'
    }).catch(()=>{});
    translateDOM();
    window.dispatchEvent(new Event('afi-language-change'));
  }
  window.AFI_LOCALE={get language(){return selected;},get mode(){return mode;},get systemLanguage(){return systemLanguage;},translateText,translateDOM,change};
  const selector=document.getElementById('afiLang');
  if(selector){
    const autoOption=document.createElement('option');
    autoOption.value='auto';
    autoOption.textContent=autoLabels[selected]+' — '+languageNames[systemLanguage];
    selector.append(autoOption);
    for(const code of codeList){const option=document.createElement('option');option.value=code;option.textContent=languageNames[code];selector.append(option);}
    selector.addEventListener('change',e=>change(e.target.value));
  }
  translateDOM();
})();

