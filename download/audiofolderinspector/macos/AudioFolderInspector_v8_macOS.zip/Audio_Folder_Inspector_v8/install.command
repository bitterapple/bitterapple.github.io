#!/bin/zsh
set -eu
cd "${0:A:h}"
services="$HOME/Library/Services"
workflow="Audio Folder Inspector.workflow"
target="$services/$workflow"
# Recognize the original workflow name when upgrading an existing installation.
legacy_name=$'\u97f3\u58f0\u30d5\u30a9\u30eb\u30c0\u60c5\u5831.workflow'
/bin/mkdir -p "$services"
if [[ ! -d "$workflow" ]]; then
  print -u2 'Audio Folder Inspector.workflow is missing. Extract the complete ZIP and try again.'
  exit 1
fi
for previous in "$target" "$services/$legacy_name"; do
  if [[ -d "$previous" ]]; then
    backup="$previous.backup.$(/bin/date +%Y%m%d_%H%M%S).$$"
    /bin/mv "$previous" "$backup"
    echo "Previous version backed up: $backup"
  fi
done
/bin/cp -R "$workflow" "$target"
if [[ -x /System/Library/CoreServices/pbs ]]; then
  /System/Library/CoreServices/pbs -flush || true
  /System/Library/CoreServices/pbs -update || true
fi
printf '\nInstalled: %s\n' "$target"
print 'Finder → Quick Actions → Audio Folder Inspector'
print 'If the action is not visible, restart Finder.'
read '?Press Return to close.'
