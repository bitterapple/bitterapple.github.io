#!/usr/bin/env python3
"""Audio Folder Inspector v8 — system-language-aware, multilingual read-only Quick Action + waveform player.

Uses only Python stdlib, ffprobe and ffmpeg. No processing writes to input audio.
BWF/iXML are read directly from RIFF chunks, with conservative bounds checks.
"""
from __future__ import annotations

import csv
import base64
import array
import secrets
import datetime as dt
import hashlib
import html
import json
import math
import os
from pathlib import Path
import re
import shutil
import statistics
import struct
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote
from uuid import uuid4

VERSION = 5  # preserve v6 audio measurements cache; quality rules are recalculated
EXTENSIONS = {
    '.wav', '.wave', '.bwf', '.aif', '.aiff', '.aifc', '.caf', '.flac',
    '.mp3', '.m4a', '.aac', '.alac', '.ogg', '.opus', '.wma', '.wv',
    '.ape', '.mka', '.mp4', '.mov', '.dsf', '.dff',
}
CACHE_DIR = Path.home() / 'Library' / 'Caches' / 'AudioFolderInspector'
REPORT_DIR = CACHE_DIR / 'Reports'
CACHE_FILE = CACHE_DIR / 'cache_v4.json'
CONFIG_FILE = Path.home() / 'Library' / 'Application Support' / 'AudioFolderInspector' / 'config.json'
PROBE_TIMEOUT = 45
REFRESH = 4
DEFAULT_CONFIG = {
    '_description': 'null disables an explicit target. When sample rate/bit depth/format/channels are null, flag deviations from the most common value.',
    'expected_sample_rate_hz': None,
    'expected_bit_depth': None,
    'expected_format': None,
    'expected_channels': None,
    'expected_sample_count': None,
    'integrated_lufs_min': None,
    'integrated_lufs_max': None,
    'lufs_outlier_from_median_lu': 6.0,
    'true_peak_max_dbtp': 0.0,
    'sample_peak_clip_threshold_dbfs': -0.01,
    'leading_silence_warning_sec': 1.0,
    'trailing_silence_warning_sec': 1.0,
    'silence_detection_dbfs': -60.0,
    'effective_silence_peak_dbfs': -80.0,
    'silence_detection_min_sec': 0.12,
    'dc_offset_warning_percent': 1.0,
    'stereo_imbalance_warning_db': 3.0,
    'dual_mono_difference_db': -70.0,
    'worker_count': 2,
    'waveform_bins': 640,
    'ui_language': 'auto',  # auto follows macOS; explicit: en, ja, fr, de, es, zh-CN, ko
}


def find_tool(tool):
    for folder in ('/opt/homebrew/bin', '/usr/local/bin', '/usr/bin'):
        p = Path(folder) / tool
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)
    return shutil.which(tool)


def notify(title, body, alert=False):
    if sys.platform != 'darwin':
        print(f'{title}: {body}', file=sys.stderr)
        return
    statement = ('display alert (item 1 of argv) message (item 2 of argv)'
                 if alert else 'display notification (item 2 of argv) with title (item 1 of argv)')
    try:
        subprocess.run(['/usr/bin/osascript', '-e', 'on run argv', '-e', statement,
                        '-e', 'end run', title, body], capture_output=True, timeout=8)
    except (OSError, subprocess.TimeoutExpired):
        print(f'{title}: {body}', file=sys.stderr)


def config_load():
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(json.dumps(DEFAULT_CONFIG, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    try:
        read = json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
        if not isinstance(read, dict):
            raise ValueError('JSON object required')
    except (ValueError, OSError) as exc:
        raise ValueError(f'Cannot read configuration: {CONFIG_FILE}: {exc}')
    # v5 wrote 'en' by default even on Japanese macOS installations.
    # On the first v6 run, migrate that old default to 'auto'. An explicit
    # English preference can be restored via the language menu or config.json.
    if read.get('ui_language') == 'en' and read.get('_afi_language_v6_migrated') is not True:
        read['ui_language'] = 'auto'
        read['_afi_language_v6_migrated'] = True
        CONFIG_FILE.write_text(json.dumps(read, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    config = DEFAULT_CONFIG.copy()
    config.update({k: v for k, v in read.items() if k in DEFAULT_CONFIG})
    if config['ui_language'] not in ('auto','en','ja','fr','de','es','zh-CN','ko'):
        raise ValueError('ui_language must be auto, en, ja, fr, de, es, zh-CN, or ko')
    for key, low, high in (
        ('worker_count', 1, 8), ('waveform_bins', 128, 2048), ('silence_detection_min_sec', 0.01, 10),
        ('silence_detection_dbfs', -120, -1),
        ('effective_silence_peak_dbfs', -150, -1),
        ('leading_silence_warning_sec', 0, 10000), ('trailing_silence_warning_sec', 0, 10000),
        ('dc_offset_warning_percent', 0, 100), ('dual_mono_difference_db', -150, -1),
        ('stereo_imbalance_warning_db', 0, 100),
    ):
        val = config[key]
        if not isinstance(val, (int, float)) or isinstance(val, bool) or not math.isfinite(val) or not low <= val <= high:
            raise ValueError(f'Invalid configuration: {key} must be between {low} and {high}')
    for key in ('integrated_lufs_min', 'integrated_lufs_max', 'lufs_outlier_from_median_lu',
                'true_peak_max_dbtp', 'sample_peak_clip_threshold_dbfs'):
        val = config[key]
        if val is not None and (not isinstance(val, (int, float)) or isinstance(val, bool) or not math.isfinite(val)):
            raise ValueError(f'Invalid configuration: {key} must be a number or null')
    if config['expected_sample_count'] is not None and (not isinstance(config['expected_sample_count'], int) or isinstance(config['expected_sample_count'], bool) or config['expected_sample_count'] < 0):
        raise ValueError('expected_sample_count must be a non-negative integer or null')
    if config['integrated_lufs_min'] is not None and config['integrated_lufs_max'] is not None and config['integrated_lufs_min'] > config['integrated_lufs_max']:
        raise ValueError('integrated_lufs_min must be <= integrated_lufs_max')
    return config


SUPPORTED_LANGUAGES = ('en', 'ja', 'fr', 'de', 'es', 'zh-CN', 'ko')


def normalize_mac_language(language):
    """Map a macOS BCP-47 preferred language to a supported report language."""
    code = str(language).strip().replace('_', '-').lower()
    primary = code.split('-')[0]
    if primary == 'zh':
        # Do not silently show simplified Chinese for traditional-Chinese users.
        parts = code.split('-')
        return 'zh-CN' if 'hans' in parts or any(p in ('cn', 'sg') for p in parts) or code == 'zh' else None
    return primary if primary in SUPPORTED_LANGUAGES else None


def system_language():
    """Read macOS preferred languages in priority order at each report generation.

    Finder/Automator don't necessarily inherit the interactive shell locale;
    navigator.language can similarly differ from the macOS preference.
    """
    if sys.platform != 'darwin':
        return 'en'
    try:
        result = subprocess.run(['/usr/bin/defaults', 'read', '-g', 'AppleLanguages'],
                                capture_output=True, text=True, timeout=4, check=False)
        if result.returncode == 0:
            for code in re.findall(r'[A-Za-z]{2,3}(?:[-_][A-Za-z0-9]{2,8})*', result.stdout):
                normalized = normalize_mac_language(code)
                if normalized:
                    return normalized
    except (OSError, subprocess.TimeoutExpired):
        pass
    # Locale alone is less specific, but is preferable to a browser preference.
    try:
        result = subprocess.run(['/usr/bin/defaults', 'read', '-g', 'AppleLocale'],
                                capture_output=True, text=True, timeout=4, check=False)
        if result.returncode == 0:
            code = normalize_mac_language(result.stdout.strip().strip('"'))
            if code:
                return code
    except (OSError, subprocess.TimeoutExpired):
        pass
    return 'en'


def selected_audio_paths(args):
    paths = {}
    roots = []
    for raw in args:
        path = Path(raw).expanduser().absolute()
        if not path.exists():
            continue
        roots.append(str(path))
        if path.is_file():
            if path.suffix.lower() in EXTENSIONS and not path.name.startswith('.'):
                paths[str(path)] = path
            continue
        if not path.is_dir():
            continue
        for parent, dirs, filenames in os.walk(path, followlinks=False):
            dirs[:] = sorted(d for d in dirs if not d.startswith('.') and not (Path(parent) / d).is_symlink())
            for name in filenames:
                if name.startswith('.') or Path(name).suffix.lower() not in EXTENSIONS:
                    continue
                candidate = Path(parent) / name
                if not candidate.is_symlink():
                    paths[str(candidate)] = candidate
    return sorted(paths.values(), key=lambda x: str(x).casefold()), roots


def friendly(path, roots):
    p = Path(path)
    for s in roots:
        r = Path(s)
        if r.is_dir():
            try:
                return str(Path(r.name) / p.relative_to(r))
            except ValueError:
                pass
    return p.name


def fint(value):
    try:
        ret = int(value)
        return ret if ret > 0 else None
    except (TypeError, ValueError):
        return None


def fnum(value):
    try:
        v = float(value)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def fdb(value):
    if value is None:
        return None
    try:
        val = float(value)
        return val if not math.isnan(val) else None
    except (TypeError, ValueError):
        return None


def fmtbit(stream):
    code = stream.get('codec_name', '')
    if code.startswith('pcm_'):
        m = re.match(r'pcm_([usf])(\d+)', code)
        if m:
            return f'{m.group(2)}-bit {"float" if m.group(1) == "f" else "PCM"}'
    n = fint(stream.get('bits_per_raw_sample')) or fint(stream.get('bits_per_sample'))
    return f'{n}-bit' if n else '—'


def bwf_chunks(path):
    result = {'bwf_description': None, 'bwf_originator_reference': None,
              'bwf_originator': None, 'bwf_origination': None,
              'bwf_time_reference_samples': None, 'bwf_time_reference_tc': None,
              'ixml_project': None, 'ixml_tape': None, 'ixml_scene': None,
              'ixml_take': None, 'ixml_note': None, 'ixml_file_uid': None,
              'ixml_timecode': None, 'ixml_track_names': None}
    if path.suffix.lower() not in ('.wav', '.wave', '.bwf'):
        return result
    try:
        with path.open('rb') as f:
            head = f.read(12)
            if len(head) < 12 or head[:4] not in (b'RIFF', b'RF64', b'BW64') or head[8:12] != b'WAVE':
                return result
            end = path.stat().st_size
            ixmldata = None
            while f.tell() + 8 <= end:
                ch = f.read(8)
                if len(ch) < 8:
                    break
                tag, length = ch[:4], struct.unpack('<I', ch[4:])[0]
                offset = f.tell()
                if length == 0xFFFFFFFF or offset + length > end:
                    break
                if tag == b'bext' and length >= 346:
                    blob = f.read(min(length, 700))
                    def gettxt(a, b):
                        return blob[a:b].split(b'\x00', 1)[0].decode('utf-8', 'replace').strip() or None
                    result['bwf_description'] = gettxt(0, 256)
                    result['bwf_originator_reference'] = gettxt(288, 320)
                    result['bwf_originator'] = gettxt(256, 288)
                    result['bwf_origination'] = ' '.join(filter(None, [gettxt(320, 330), gettxt(330, 338)])) or None
                    if len(blob) >= 346:
                        lo, hi = struct.unpack_from('<II', blob, 338)
                        result['bwf_time_reference_samples'] = hi * (1 << 32) + lo
                elif tag == b'iXML' and length <= 2_000_000:
                    ixmldata = f.read(length)
                f.seek(offset + length + (length & 1))
            if ixmldata:
                try:
                    tree = ET.fromstring(ixmldata.rstrip(b'\x00').decode('utf-8-sig', 'replace'))
                    wanted = {'PROJECT': 'ixml_project', 'TAPE': 'ixml_tape',
                              'SCENE': 'ixml_scene', 'TAKE': 'ixml_take',
                              'NOTE': 'ixml_note', 'FILE_UID': 'ixml_file_uid'}
                    for el in tree.iter():
                        name = el.tag.rsplit('}', 1)[-1].upper()
                        if name in wanted and result[wanted[name]] is None and el.text:
                            result[wanted[name]] = el.text.strip()[:1500]
                    rate = tree.findtext('.//TIMECODE_RATE') or tree.findtext('.//SPEED/TIMECODE_RATE')
                    flag = tree.findtext('.//TIMECODE_FLAG')
                    if rate:
                        result['ixml_timecode'] = rate.strip() + ((' / ' + flag.strip()) if flag else '')
                    tracks = [x.text.strip() for x in tree.iter()
                              if x.tag.rsplit('}', 1)[-1].upper() == 'NAME' and x.text and x.text.strip()]
                    if tracks:
                        result['ixml_track_names'] = ', '.join(tracks[:16])[:500]
                except ET.ParseError:
                    result['ixml_note'] = 'Invalid iXML XML'
    except (OSError, ValueError, struct.error):
        pass
    return result


def blank_row(path):
    return dict(path=str(path), size=None, format=path.suffix.upper().lstrip('.'),
                codec='—', sr=None, channels=None, channel_layout='—', depth='—',
                bitrate=None, bitrate_estimated=False, duration=None, sample_count=None,
                lufs=None, lra=None, true_peak=None, sample_peak=None, lufs_valid=True,
                channel_rms=[], channel_dc=[], rms=None, dc_offset=None,
                lead_silence=None, tail_silence=None, is_silent=False, is_effective_silent=False,
                dual_mono=None, stereo_difference_db=None, stereo_balance_db=None,
                warnings=[], issue_codes=[], severity='pending', status='解析待ち', audio_streams=0,
                bwf_description=None, bwf_originator_reference=None,
                bwf_originator=None, bwf_origination=None, bwf_time_reference_samples=None,
                bwf_time_reference_tc=None, waveform=None, ixml_project=None, ixml_tape=None,
                ixml_scene=None, ixml_take=None, ixml_note=None,
                ixml_file_uid=None, ixml_timecode=None, ixml_track_names=None)


def probe(path, ffprobe):
    row = blank_row(path)
    row['size'] = path.stat().st_size
    cmd = [ffprobe, '-v', 'error', '-show_entries',
           'format=duration,bit_rate:stream=index,codec_type,codec_name,sample_rate,channels,channel_layout,'
           'bits_per_raw_sample,bits_per_sample,bit_rate,duration,duration_ts,time_base,nb_samples',
           '-of', 'json', str(path)]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, errors='replace', timeout=PROBE_TIMEOUT)
        if proc.returncode:
            raise ValueError(proc.stderr.strip()[:200] or 'ffprobe read failure')
        doc = json.loads(proc.stdout)
        streams = [s for s in doc.get('streams', []) if s.get('codec_type') == 'audio']
        if not streams:
            raise ValueError('No audio stream')
        s = streams[0]
        fmt = doc.get('format', {})
        row.update(codec=s.get('codec_name') or '不明', sr=fint(s.get('sample_rate')),
                   channels=fint(s.get('channels')),
                   channel_layout=s.get('channel_layout') or '—',
                   depth=fmtbit(s),
                   duration=fnum(s.get('duration')) or fnum(fmt.get('duration')),
                   audio_streams=len(streams))
        rate = fint(s.get('bit_rate'))
        if not rate and len(doc.get('streams', [])) == 1:
            rate = fint(fmt.get('bit_rate'))
            row['bitrate_estimated'] = rate is not None
        row['bitrate'] = rate
        if len(streams) > 1:
            row['warnings'].append(f'音声ストリーム{len(streams)}本。1本目のみ解析')
            row['issue_codes'].append('multiple_streams')
        row.update(bwf_chunks(path))
        if row['bwf_time_reference_samples'] is not None and row['sr']:
            sec = row['bwf_time_reference_samples'] / row['sr']
            h = int(sec // 3600)
            row['bwf_time_reference_tc'] = f'{h:02}:{int(sec//60)%60:02}:{int(sec)%60:02}.{int((sec%1)*1000):03}'
    except (OSError, ValueError, subprocess.TimeoutExpired, json.JSONDecodeError) as exc:
        row['status'] = '読取不可'
        row['warnings'].append(str(exc)[:200])
        row['issue_codes'].append('unreadable')
    return row


def parse_astats(log):
    """Return channel dicts plus overall dict. Ignores other filters' lines."""
    channels, overall, cur = [], {}, None
    for raw in log.splitlines():
        if 'astats_' not in raw:
            continue
        msg = raw.split('] ', 1)[-1].strip()
        if msg.startswith('Channel:'):
            cur = {}
            channels.append(cur)
        elif msg == 'Overall':
            cur = overall
        elif cur is not None and ': ' in msg:
            k, v = msg.split(': ', 1)
            cur[k.strip()] = v.strip()
    return channels, overall


def detect_silence(log, duration):
    beginnings = [float(x) for x in re.findall(r'\bsilence_start:\s*([\d.]+)', log)]
    ends = [float(x) for x in re.findall(r'\bsilence_end:\s*([\d.]+)', log)]
    if not beginnings:
        return 0.0, 0.0
    # Each complete interval is normally emitted as silence_start then silence_end.
    # Ends are sorted chronologically; a trailing interval may have an EOF event.
    intervals = []
    for idx, start in enumerate(beginnings):
        end = ends[idx] if idx < len(ends) else duration
        if end is not None and end >= start:
            intervals.append((start, end))
    lead = 0.0
    tail = 0.0
    if intervals and intervals[0][0] <= .08:
        lead = max(0.0, intervals[0][1] - intervals[0][0])
    if duration is not None and intervals and abs(intervals[-1][1] - duration) <= .2:
        tail = max(0.0, intervals[-1][1] - intervals[-1][0])
    return lead, tail


def measure(row, ffmpeg, config):
    if row['status'] == '読取不可':
        return row
    noise = config['silence_detection_dbfs']
    minimum = config['silence_detection_min_sec']
    filterstr = (f'ebur128=peak=true:framelog=verbose,'
                 f'astats=metadata=0:reset=0,'
                 f'silencedetect=noise={noise}dB:d={minimum}')
    cmd = [ffmpeg, '-hide_banner', '-nostdin', '-nostats', '-loglevel', 'info',
           '-threads', '1', '-i', row['path'], '-map', '0:a:0', '-vn', '-sn', '-dn',
           '-af', filterstr, '-f', 'null', '-']
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, errors='replace')
        log = proc.stderr
        get = lambda pattern: re.findall(pattern, log, re.I)
        m = get(r'Integrated loudness:\s*I:\s*(-?inf|[-+]?\d+(?:\.\d+)?)\s*LUFS')
        lra = get(r'Loudness range:\s*LRA:\s*([-+]?\d+(?:\.\d+)?)\s*LU')
        tp = get(r'True peak:\s*Peak:\s*(-?inf|[-+]?\d+(?:\.\d+)?)\s*dBFS')
        if not m:
            raise ValueError('Integrated LUFSを測定できませんでした: ' + log.strip()[-180:])
        row['lufs'] = fdb(m[-1])
        row['lra'] = fnum(lra[-1]) if lra else None
        row['true_peak'] = fdb(tp[-1]) if tp else None
        channels, whole = parse_astats(log)
        row['sample_peak'] = fdb(whole.get('Peak level dB'))
        row['rms'] = fdb(whole.get('RMS level dB'))
        row['dc_offset'] = fnum(whole.get('DC offset'))
        row['sample_count'] = fint(whole.get('Number of samples'))
        row['channel_rms'] = [fdb(x.get('RMS level dB')) for x in channels]
        row['channel_dc'] = [fnum(x.get('DC offset')) for x in channels]
        if row['channel_dc']:
            dcs = [x for x in row['channel_dc'] if x is not None]
            if dcs:
                row['dc_offset'] = max(dcs, key=abs)  # avoid stereo DC cancellation
        lead, tail = detect_silence(log, row['duration'])
        row['lead_silence'], row['tail_silence'] = lead, tail
        # Strictly digital silence is proven by -inf sample peak, not LUFS gating alone.
        row['is_silent'] = row['sample_peak'] == float('-inf')
        row['is_effective_silent'] = bool(row['is_silent'] or
            (row['sample_peak'] is not None and row['sample_peak'] <= config['effective_silence_peak_dbfs']))
        if row['is_silent']:
            row['lufs'] = float('-inf')
        if ((row['duration'] is not None and row['duration'] < .4) or
                (row['lufs'] is not None and row['lufs'] <= -69.9 and not row['is_silent'])):
            row['lufs_valid'] = False
            if not row['is_silent']:
                row['lufs'] = None
            row['lra'] = None
        decode = re.search(r'(corrupt decoded|Error while decoding|Invalid data found when processing|'
                           r'concealing \d+|header damaged|Error submitting packet|Packet corrupt)', log, re.I)
        if proc.returncode or decode:
            row['status'] = '要確認'
            row['warnings'].append('デコードエラーまたは警告' + (f' (exit={proc.returncode})' if proc.returncode else ''))
            row['issue_codes'].append('decode_error')
        else:
            row['status'] = 'OK'
        if row['channels'] == 2 and not decode and not proc.returncode and row['channel_rms'] and len(row['channel_rms']) >= 2:
            stereo_measure(row, ffmpeg)
    except (OSError, ValueError) as exc:
        row['status'] = '解析失敗'
        row['warnings'].append(str(exc)[:250])
        row['issue_codes'].append('analysis_failed')
    return row


def stereo_measure(row, ffmpeg):
    left, right = row['channel_rms'][:2]
    if left is not None and right is not None and math.isfinite(left) and math.isfinite(right):
        row['stereo_balance_db'] = round(left - right, 3)
    elif left == float('-inf') and right is not None:
        row['stereo_balance_db'] = float('-inf')
    elif right == float('-inf') and left is not None:
        row['stereo_balance_db'] = float('inf')
    cmd = [ffmpeg, '-hide_banner', '-nostdin', '-nostats', '-loglevel', 'info',
           '-threads', '1', '-i', row['path'], '-map', '0:a:0', '-vn', '-sn', '-dn',
           '-af', 'pan=mono|c0=c0-c1,astats=metadata=0:reset=0', '-f', 'null', '-']
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, errors='replace')
        if proc.returncode:
            return
        _, whole = parse_astats(proc.stderr)
        diff = fdb(whole.get('RMS level dB'))
        ref = max([x for x in (left, right) if x is not None], default=None)
        if diff is not None and ref is not None and math.isfinite(ref):
            row['stereo_difference_db'] = (diff - ref if math.isfinite(diff) else float('-inf'))
            # Very small difference indicates dual mono. A left/right silence pair
            # is not marked as dual mono even though their difference could be low.
            row['dual_mono'] = row['stereo_difference_db'] <= -70.0
    except (OSError, ValueError):
        pass


def waveform_peaks(path, ffmpeg, duration, bins=640):
    """Make a small 8-bit envelope; stream ~8k decoded samples/sec, never full audio RAM.

    The waveform is only a visual overview, not full-band / sample-accurate peak metering.
    Audio is never modified; no preview audio is generated during scanning.
    """
    if not duration or duration <= 0:
        return [0] * bins
    sample_rate = 8000
    expected = max(1, int(round(float(duration) * sample_rate)))
    magnitudes = [0] * bins
    command = [ffmpeg, '-hide_banner', '-nostdin', '-loglevel', 'error',
               '-threads', '1', '-i', str(path), '-map', '0:a:0',
               '-vn', '-sn', '-dn', '-ac', '1', '-ar', str(sample_rate),
               '-c:a', 'pcm_s16le', '-f', 's16le', 'pipe:1']
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    total = 0
    try:
        # Stream in bounded chunks (64 KiB). Never read the whole decoded file.
        while True:
            raw = proc.stdout.read(65536)
            if not raw:
                break
            data = array.array('h')
            data.frombytes(raw)
            if sys.byteorder != 'little': data.byteswap()
            # Aggregate sample peaks into at most `bins` windows; if the decode
            # exceeds duration reported by ffprobe, clamp the final small overrun.
            for sample in data:
                bucket = min(bins - 1, (total * bins) // expected)
                amp = abs(sample)
                if amp > magnitudes[bucket]: magnitudes[bucket] = amp
                total += 1
        proc.wait(timeout=10)
        if proc.returncode:
            return None
        # Brighten quiet speech for legibility. The values are NOT dB measurements.
        return [min(255, int(round((v/32768.0) ** .65 * 255))) for v in magnitudes]
    except (OSError, subprocess.TimeoutExpired):
        proc.kill()
        proc.wait()
        return None
    finally:
        if proc.stdout: proc.stdout.close()


def compact_wave(row):
    values = row.get('waveform')
    if not isinstance(values, list) or not values:
        return None
    if any(not isinstance(x, int) or x < 0 or x > 255 for x in values):
        return None
    return base64.b64encode(bytes(values)).decode('ascii')


def start_player_server(report, files, ffmpeg):
    """Launch a one-report 127.0.0.1 server. Returns its unguessable base URL.

    Static report still works when the service expires, but audio playback needs
    the server (re-run Finder Quick Action to start a new one).
    """
    if os.getenv('AFI_DISABLE_SERVER') == '1':
        return None
    server_file = Path(__file__).with_name('afi_player_server.py')
    if not server_file.is_file():
        return None
    manifest = report.with_suffix('.manifest.json')
    data = {
        'token': secrets.token_urlsafe(24),
        'report': str(report),
        'ffmpeg': ffmpeg,
        'cache': str(CACHE_DIR / 'Previews'),
        'config_file': str(CONFIG_FILE),
        'files': [],
    }
    for p in files:
        st = p.stat()
        data['files'].append({'path':str(p),'size':st.st_size,'mtime_ns':st.st_mtime_ns,
                              'ino':st.st_ino,'dev':st.st_dev})
    manifest.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    os.chmod(manifest, 0o600)
    marker = manifest.with_suffix('.server.json')
    try:
        subprocess.Popen([sys.executable, str(server_file), str(manifest)],
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
        for _ in range(50):
            if marker.is_file():
                address=json.loads(marker.read_text())
                if address.get('token')==data['token'] and int(address['port'])>0:
                    return f"http://127.0.0.1:{address['port']}/{data['token']}"
            time.sleep(.1)
    except (OSError, ValueError, json.JSONDecodeError):
        pass
    return None


def base_key(path, config):
    s = path.stat()
    analysis_cfg = {k: config[k] for k in ('silence_detection_dbfs', 'silence_detection_min_sec')}
    payload = f'{VERSION}\0{path}\0{s.st_size}\0{s.st_mtime_ns}\0{json.dumps(analysis_cfg,sort_keys=True)}'
    return hashlib.sha256(payload.encode()).hexdigest()


# Quality levels are independent of decoder status and do not alter audio analysis.
# Informational findings never inflate the Needs Attention count.
ISSUE_SEVERITY = {
    'unreadable':'error', 'analysis_failed':'error', 'decode_error':'error',
    'multiple_streams':'warning',
    'rate_mismatch':'warning', 'sample_count_mismatch':'warning',
    'depth_mismatch':'warning', 'format_mismatch':'warning', 'channel_mismatch':'warning',
    'silent':'warning', 'effective_silence':'warning',
    'lufs_unavailable':'info',
    'lufs_range':'warning', 'lufs_outlier':'warning',
    'true_peak_high':'warning', 'clip_suspected':'warning',
    'long_head':'warning', 'long_tail':'warning',
    'dc_offset':'warning', 'imbalance':'warning',
    'dual_mono':'info',
}
SEVERITY_RANK = {'ok':0, 'info':1, 'warning':2, 'error':3, 'pending':-1}
SEVERITY_JA = {'ok':'OK', 'info':'情報', 'warning':'注意', 'error':'エラー', 'pending':'解析待ち'}
RULE_MESSAGES = {
    'rate_mismatch': 'サンプルレート不一致',
    'sample_count_mismatch': 'サンプル数不一致',
    'depth_mismatch': 'ビット深度不一致',
    'format_mismatch': 'ファイル形式不一致',
    'channel_mismatch': 'チャンネル数不一致',
    'silent': 'デジタル無音ファイル',
    'lufs_unavailable': 'LUFS計測不可（短尺またはゲーティング）',
    'effective_silence': '実質無音ファイル',
    'lufs_range': 'LUFS指定範囲外',
    'lufs_outlier': 'LUFS中央値からの偏差大',
    'true_peak_high': 'True Peak上限超過',
    'clip_suspected': 'クリッピング疑い（サンプルピーク）',
    'long_head': '冒頭無音が長い',
    'long_tail': '末尾無音が長い',
    'dc_offset': 'DCオフセット大',
    'imbalance': '左右レベル差大',
    'dual_mono': 'ステレオ内Dual Mono',
    'multiple_streams': '音声ストリームが複数（1本目のみ解析）',
    'unreadable': '読み取り不可',
    'analysis_failed': '解析失敗',
    'decode_error': 'デコードエラー',
}
COMPUTED_CODES = {
    'rate_mismatch', 'sample_count_mismatch', 'depth_mismatch',
    'format_mismatch', 'channel_mismatch', 'silent', 'lufs_unavailable',
    'effective_silence', 'lufs_range', 'lufs_outlier', 'true_peak_high',
    'clip_suspected', 'long_head', 'long_tail', 'dc_offset',
    'imbalance', 'dual_mono',
}

def severity_of(row):
    if row.get('status') == '解析待ち':
        return 'pending'
    codes = row.get('issue_codes', [])
    found = [ISSUE_SEVERITY.get(code, 'warning') for code in codes]
    if row.get('status') in ('読取不可', '解析失敗', '要確認'):
        found.append('error')
    return max(found, key=lambda v: SEVERITY_RANK.get(v, 0), default='ok')

def needs_attention(row):
    return severity_of(row) in ('warning', 'error')

def add_issue(r, code):
    if code not in r['issue_codes']:
        r['issue_codes'].append(code)
        if code in RULE_MESSAGES:
            r['warnings'].append(RULE_MESSAGES[code])


def check_rules(rows, config):
    """Compare unset expected specs against the majority of the IMMEDIATE folder.

    Tied values and a singleton cannot establish a reliable implicit standard.
    Explicit expected_* config always takes precedence, even in mixed folders.
    """
    buckets = {}
    for row in rows:
        folder = str(Path(row['path']).parent)
        buckets.setdefault(folder, []).append(row)
    for leaf_rows in buckets.values():
        # The pending subset is intentionally ignored while analysis progresses.
        done = [r for r in leaf_rows if r.get('status') not in ('解析待ち', '読取不可', '解析失敗')]
        def expected(key, field):
            override = config.get(key)
            if override is not None:
                return override.upper() if field == 'format' and isinstance(override, str) else override
            vals = [r[field] for r in done if r.get(field) not in (None, '—')]
            counts = Counter(vals).most_common()
            if not counts or counts[0][1] < 2:
                return None
            if len(counts) > 1 and counts[0][1] == counts[1][1]:
                return None
            return counts[0][0]
        specs = {
            'sr': (expected('expected_sample_rate_hz','sr'), 'rate_mismatch'),
            'depth': (expected('expected_bit_depth','depth'), 'depth_mismatch'),
            'format': (expected('expected_format','format'), 'format_mismatch'),
            'channels': (expected('expected_channels','channels'), 'channel_mismatch'),
        }
        measured_lufs = [r['lufs'] for r in done if r.get('lufs_valid', True)
                         and r.get('lufs') is not None and math.isfinite(r['lufs'])
                         and r.get('status') == 'OK']
        median = statistics.median(measured_lufs) if measured_lufs else None
        for r in leaf_rows:
            # Keep true read/decode issues intact. Rule changes must not erase them.
            stable_codes = [c for c in r.get('issue_codes', []) if c not in COMPUTED_CODES]
            old_derived = [RULE_MESSAGES[c] for c in COMPUTED_CODES if c in RULE_MESSAGES]
            r['issue_codes'] = stable_codes
            r['warnings'] = [w for w in r.get('warnings', []) if w not in old_derived]
            if r['status'] in ('解析待ち', '解析失敗', '読取不可'):
                r['severity'] = severity_of(r)
                continue
            for field, (expect, code) in specs.items():
                if expect is not None and r.get(field) not in (None, '—') and r[field] != expect:
                    add_issue(r, code)
            if config['expected_sample_count'] is not None and r.get('sample_count') is not None and r['sample_count'] != config['expected_sample_count']:
                add_issue(r, 'sample_count_mismatch')
            if r.get('lufs_valid') is False:
                add_issue(r, 'lufs_unavailable')
            if r['is_silent']:
                add_issue(r, 'silent')
            elif r.get('is_effective_silent'):
                add_issue(r, 'effective_silence')
            lufs = r['lufs']
            if lufs is not None and math.isfinite(lufs):
                low, high = config['integrated_lufs_min'], config['integrated_lufs_max']
                if (low is not None and lufs < low) or (high is not None and lufs > high):
                    add_issue(r, 'lufs_range')
                delta = config['lufs_outlier_from_median_lu']
                if delta is not None and median is not None and abs(lufs - median) > delta:
                    add_issue(r, 'lufs_outlier')
            tp = r.get('true_peak')
            if tp is not None and config['true_peak_max_dbtp'] is not None and tp > config['true_peak_max_dbtp']:
                add_issue(r, 'true_peak_high')
            peak = r.get('sample_peak')
            if peak is not None and config['sample_peak_clip_threshold_dbfs'] is not None and peak >= config['sample_peak_clip_threshold_dbfs']:
                add_issue(r, 'clip_suspected')
            if r['lead_silence'] is not None and r['lead_silence'] > config['leading_silence_warning_sec']:
                add_issue(r, 'long_head')
            if r['tail_silence'] is not None and r['tail_silence'] > config['trailing_silence_warning_sec']:
                add_issue(r, 'long_tail')
            if r['dc_offset'] is not None and abs(r['dc_offset']) * 100 > config['dc_offset_warning_percent']:
                add_issue(r, 'dc_offset')
            bal = r.get('stereo_balance_db')
            if bal is not None and (not math.isfinite(bal) or abs(bal) > config['stereo_imbalance_warning_db']):
                add_issue(r, 'imbalance')
            diff = r['stereo_difference_db']
            # An exact L-R null can be -inf. The JSON cache stores that as null;
            # retain the already measured exact-dual-mono boolean in that case.
            if ((diff is not None and diff <= config['dual_mono_difference_db'])
                    or (diff is None and r.get('dual_mono') is True)):
                add_issue(r, 'dual_mono')
            r['severity'] = severity_of(r)
    # Caller does not rely on the old global spec/median return value.
    return None, None


def issue_class(code):
    return {'error':'bad', 'warning':'warn', 'info':'info', 'ok':'ok'}.get(ISSUE_SEVERITY.get(code,'warning'),'warn')

def status_class(severity):
    return {'error':'bad', 'warning':'warn', 'info':'info', 'ok':'ok'}.get(severity,'')

def issue_detail(row):
    listed = [RULE_MESSAGES.get(code, code) for code in row.get('issue_codes', [])]
    # Preserve diagnostic details (e.g. ffprobe failure or the actual decoder exit code).
    known = set(RULE_MESSAGES.values())
    return listed + [w for w in row.get('warnings', []) if w not in known and w not in listed]

def jesc(v):
    return html.escape(str(v), quote=True)


def rate_label(sr):
    return (f'{sr / 1000:g} kHz' if sr else '—')


def dur_label(sec):
    if sec is None:
        return '—'
    n = int(sec)
    return f'{n//3600}:{(n//60)%60:02}:{n%60:02}'


def db_label(v, unit='', digs=2):
    if v is None:
        return '—'
    if math.isinf(v):
        return ('−∞' if v < 0 else '+∞') + unit
    return f'{v:.{digs}f}{unit}'


def size_label(n):
    if n is None:
        return '—'
    v = float(n)
    for unit in ('B','KiB','MiB','GiB','TiB'):
        if v < 1024 or unit == 'TiB':
            return f'{v:,.1f} {unit}'
        v /= 1024


def dist(items, formatfn=str):
    counter = Counter(v for v in items if v is not None)
    if not counter:
        return '—'
    return ' · '.join(f'{formatfn(k)} × {n}' for k, n in sorted(counter.items(), key=lambda x: (-x[1], str(x[0]))))



def group_folders(rows, roots):
    """Group audio by immediate folder and by descendant hierarchy, once per file.

    One directory path has one identity even if selected roots overlap. A file
    selected by itself is represented under its parent. Empty selected roots are
    included, but non-audio empty descendants are not recursively enumerated.
    """
    selected_dirs = [Path(x) for x in roots if Path(x).is_dir()]
    dirs = {}
    def add(folder):
        key = str(folder)
        if key not in dirs:
            dirs[key] = {'path': folder, 'direct': [], 'subtree': []}
        return dirs[key]

    for root in selected_dirs:
        add(root)

    # Include ancestors up to the selected directory root, but never escape it.
    for index, row in enumerate(rows):
        path = Path(row['path'])
        matching = [root for root in selected_dirs if path == root or root in path.parents]
        highest = min(matching, key=lambda root: len(root.parts)) if matching else path.parent
        cur = path.parent
        add(cur)['direct'].append(index)
        while True:
            add(cur)['subtree'].append(index)
            if cur == highest or cur == cur.parent:
                break
            cur = cur.parent

    def display(folder):
        candidates = [root for root in selected_dirs if folder == root or root in folder.parents]
        if candidates:
            root = min(candidates, key=lambda r: len(r.parts))
            return str(Path(root.name) / folder.relative_to(root))
        return folder.name or str(folder)

    ordered = sorted(dirs.values(), key=lambda d: (len(d['path'].parts), str(d['path']).casefold()))
    for index, group in enumerate(ordered):
        group['id'] = str(index)
        group['name'] = display(group['path'])
        group['depth'] = max(0, len(Path(group['name']).parts)-1)
        group['direct'] = sorted(set(group['direct']))
        group['subtree'] = sorted(set(group['subtree']))
    # Ensure parent rows sort before children even across multiple selected roots.
    ordered.sort(key=lambda g: tuple(part.casefold() for part in Path(g['name']).parts))
    for i, group in enumerate(ordered):
        group['id'] = str(i)
    bypath = {str(g['path']): g for g in ordered}
    for group in ordered:
        group['parent_id'] = (bypath[str(group['path'].parent)]['id']
                              if str(group['path'].parent) in bypath else None)
    return ordered


def folder_statistics(group_rows):
    """Stats for exactly these rows; the caller selects direct or recursive rows."""
    observed = [r for r in group_rows if r['status'] != '解析待ち']
    metadata = [r for r in observed if r['sr'] is not None]
    good_lufs = [r['lufs'] for r in observed
                 if r['status'] not in ('読取不可','解析失敗','要確認') and r.get('lufs_valid', True)
                 and r.get('lufs') is not None and math.isfinite(r['lufs'])]
    bitrates = [r for r in metadata if r.get('bitrate') is not None
                and r.get('duration') is not None and r['duration'] > 0]
    duration_known = sum(r['duration'] for r in metadata if r['duration'] is not None)
    rate_duration = sum(r['duration'] for r in bitrates)
    peaks = [r['true_peak'] for r in observed
             if r.get('true_peak') is not None and math.isfinite(r['true_peak'])]
    sample_peaks = [r['sample_peak'] for r in observed
                    if r.get('sample_peak') is not None and math.isfinite(r['sample_peak'])]
    lras = [r['lra'] for r in observed if r.get('lra') is not None and math.isfinite(r['lra'])]
    return {
        'files': len(group_rows), 'completed': len(observed),
        'duration': duration_known,
        'size': sum(r['size'] for r in observed if r['size'] is not None),
        'avg_lufs': statistics.mean(good_lufs) if good_lufs else None,
        'median_lufs': statistics.median(good_lufs) if good_lufs else None,
        'min_lufs': min(good_lufs) if good_lufs else None,
        'max_lufs': max(good_lufs) if good_lufs else None,
        'std_lufs': statistics.stdev(good_lufs) if len(good_lufs)>=2 else (0.0 if len(good_lufs)==1 else None),
        'lufs_count': len(good_lufs), 'lufs_unmeasurable': sum(bool(r.get('lufs_valid') is False) or r.get('lufs') is None for r in observed),
        'avg_lra': statistics.mean(lras) if lras else None,
        'max_tp': max(peaks) if peaks else None,
        'max_sp': max(sample_peaks) if sample_peaks else None,
        'bitrate_weighted': (sum(r['bitrate']*r['duration'] for r in bitrates)/rate_duration if rate_duration else None),
        'issues': sum(needs_attention(r) for r in observed),
        'infos': sum(severity_of(r) == 'info' for r in observed),
        'warnings': sum(severity_of(r) == 'warning' for r in observed),
        'errors': sum(severity_of(r) == 'error' for r in observed),
        'silents': sum(bool(r.get('is_silent')) for r in observed),
        'effective_silents': sum(bool(r.get('is_effective_silent')) for r in observed),
        'bwf': sum(r.get('bwf_time_reference_samples') is not None or
                   any(r.get(x) for x in ('ixml_project','ixml_scene','ixml_take','ixml_file_uid')) for r in observed),
        'formats': dist((r['format'] for r in metadata)),
        'codecs': dist((r['codec'] for r in metadata)),
        'sample_rates': dist((r['sr'] for r in metadata),rate_label),
        'depths': dist((r['depth'] for r in metadata)),
        'channels': dist((f"{r['channels']}ch / {r['channel_layout']}" for r in metadata)),
        'bitrates': dist((f"{round(r['bitrate']/1000)} kb/s" if r['bitrate'] else '不明' for r in metadata)),
        'warning_counts': Counter(code for r in observed for code in r['issue_codes']),
    }


def folder_metric_cards(st):
    cards = [
        ('音声ファイル', f"{st['files']:,}", f"解析済み {st['completed']:,}"),
        ('平均 LUFS-I', db_label(st['avg_lufs']), f"有効 {st['lufs_count']}件"),
        ('中央値 / 標準偏差', db_label(st['median_lufs'],digs=1)+' / '+db_label(st['std_lufs'],digs=1), 'LUFS / LU'),
        ('最小 / 最大 LUFS', db_label(st['min_lufs'],digs=1)+' / '+db_label(st['max_lufs'],digs=1), '有効値のみ'),
        ('最大 True Peak', db_label(st['max_tp']), 'dBTP'),
        ('最大 Sample Peak', db_label(st['max_sp']), 'dBFS'),
        ('総再生時間', dur_label(st['duration']), '取得できた長さの合計'),
        ('総ファイル容量', size_label(st['size']), '解析済みファイル'),
        ('要確認ファイル', str(st['issues']), f"注意 {st['warnings']}件 / エラー {st['errors']}件 / 情報 {st['infos']}件"),
        ('無音 / 実質無音', f"{st['silents']} / {st['effective_silents']}", '完全無音 / 閾値以下'),
        ('BWF / iXML', str(st['bwf']), 'メタデータ検出数'),
    ]
    return ''.join(f'<article class="card"><div class="name">{jesc(x)}</div><div class="num">{jesc(y)}</div><div class="note">{jesc(z)}</div></article>' for x,y,z in cards)


def folder_panels(st):
    panels = [
        ('ファイル形式', st['formats']), ('コーデック', st['codecs']),
        ('サンプルレート', st['sample_rates']), ('ビット深度', st['depths']),
        ('チャンネル数・配置', st['channels']),
        ('ビットレート', st['bitrates'] +
         (f" / 時間加重平均 約{st['bitrate_weighted']/1000:.0f} kb/s" if st['bitrate_weighted'] else '')),
        ('平均 LRA', db_label(st['avg_lra'], ' LU')),
    ]
    result = ''.join('<article class="panel"><h2>'+jesc(title)+'</h2><p>'+jesc(val)+'</p></article>' for title,val in panels)
    if st['warning_counts']:
        counts = ''.join(f'<p><span class="pill {issue_class(k)}">{n}件</span> {jesc(SEVERITY_JA.get(ISSUE_SEVERITY.get(k, "warning"), "注意"))} · {jesc(RULE_MESSAGES.get(k,k))}</p>'
                         for k,n in st['warning_counts'].most_common())
        result += '<article class="panel"><h2>品質チェック</h2>'+counts+'</article>'
    else:
        result += '<article class="panel"><h2>品質チェック</h2><p>問題検出なし</p></article>'
    return result


def export_folder_csv(groups, rows, destination):
    heads = ['フォルダ','フォルダパス','直下件数','配下含む件数','直下解析済み','配下解析済み',
             '直下平均LUFS','配下平均LUFS','直下中央値LUFS','配下中央値LUFS',
             '直下最小LUFS','直下最大LUFS','直下LUFS標準偏差',
             '直下平均LRA','直下最大TruePeak dBTP','直下最大SamplePeak dBFS',
             '直下要確認数','配下要確認数','直下読取デコード失敗数',
             '直下完全無音数','直下実質無音数','直下BWF/iXML数',
             '直下再生時間秒','配下再生時間秒','直下ファイルサイズB','配下ファイルサイズB',
             '直下ファイル形式','直下コーデック','直下サンプルレート','直下ビット深度',
             '直下チャンネル','直下ビットレート','直下時間加重ビットレートbps','直下品質警告詳細']
    with destination.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.writer(f)
        writer.writerow(FOLDER_CSV_HEADERS_EN)
        for g in groups:
            direct=folder_statistics([rows[i] for i in g['direct']])
            subtree=folder_statistics([rows[i] for i in g['subtree']])
            items=[g['name'],str(g['path']), direct['files'],subtree['files'], direct['completed'],subtree['completed'],
                   direct['avg_lufs'],subtree['avg_lufs'],direct['median_lufs'],subtree['median_lufs'],
                   direct['min_lufs'],direct['max_lufs'],direct['std_lufs'],direct['avg_lra'],direct['max_tp'],
                   direct['max_sp'],direct['issues'],subtree['issues'],direct['errors'],direct['silents'],
                   direct['effective_silents'],direct['bwf'],direct['duration'],subtree['duration'],
                   direct['size'],subtree['size'],direct['formats'],direct['codecs'],direct['sample_rates'],
                   direct['depths'],direct['channels'],direct['bitrates'].replace('不明','Unknown'),direct['bitrate_weighted'],
                   ' / '.join(f"{CSV_ISSUES_EN.get(k,k)}: {v}" for k,v in direct['warning_counts'].most_common()),
                   direct['infos'],direct['warnings'],direct['errors'],subtree['infos'],subtree['warnings'],subtree['errors']]
            # Avoid formula injection only in externally-controlled strings; keep
            # negative LUFS / peaks numeric so Numbers and Excel can aggregate.
            for i in [0,1,26,27,28,29,30,31,33]:
                items[i]=csv_cell(items[i])
            writer.writerow(['' if v is None else v for v in items])


def render_folder_sections(rows, roots, groups):
    overview=[]
    details=[]
    perfile={}
    ancestry={}
    for g in groups:
        direct=folder_statistics([rows[i] for i in g['direct']])
        sub=folder_statistics([rows[i] for i in g['subtree']])
        g['direct_stats']=direct
        g['sub_stats']=sub
        for i in g['direct']:
            perfile[i]=g['id']
        for i in g['subtree']:
            ancestry.setdefault(i,[]).append(g['id'])
        qname=jesc(g['name'])
        ds = f"{db_label(direct['avg_lufs'],digs=1)} / {db_label(sub['avg_lufs'],digs=1)}"
        overview.append('<tr><td data-afi-untranslated><a href="#folder-'+g['id']+'">'+qname+'</a></td>'+
                        '<td>'+str(direct['files'])+' / '+str(sub['files'])+'</td>'+
                        '<td>'+ds+'</td><td>'+jesc(direct['sample_rates'])+'</td><td>'+jesc(direct['formats'])+
                        '</td><td>'+jesc(direct['depths'])+'</td><td>'+jesc(direct['bitrates'])+'</td>'+
                        '<td>'+dur_label(direct['duration'])+' / '+dur_label(sub['duration'])+'</td>'+
                        '<td>'+str(direct['issues'])+' / '+str(sub['issues'])+'</td></tr>')
        details.append(
            '<details class="folderdetail" id="folder-'+g['id']+'"><summary><strong>'+qname+'</strong>'+
            '<span class="small muted"> 直下 '+str(direct['files'])+'件 ・ 配下 '+str(sub['files'])+
            '件 ・ 要確認 '+str(direct['issues'])+' / '+str(sub['issues'])+'件（情報 '+str(direct['infos'])+'件）</span></summary>'+
            '<div class="folderinner"><div class="folderactions"><a href="#filelist" onclick="showFolder('+g['id']+',\'direct\')">直下ファイルを一覧で見る</a>'+
            '<a href="#filelist" onclick="showFolder('+g['id']+',\'subtree\')">子フォルダも含めた一覧を見る</a></div>'+
            '<h3>このフォルダ直下の音声</h3><section class="cards">'+folder_metric_cards(direct)+'</section>'+
            '<section class="grids">'+folder_panels(direct)+'</section>'+
            '<h3>サブフォルダを含む合計</h3><section class="cards">'+folder_metric_cards(sub)+'</section>'+
            '<section class="grids">'+folder_panels(sub)+'</section></div></details>'
        )
    select = ''.join('<option data-afi-untranslated value="'+g['id']+'">'+jesc(g['name'])+'</option>' for g in groups)
    section = (
        '<div class="sectionhead"><h2>フォルダ別集計</h2><p class="muted small">左：直下のみ / 右：子フォルダも含む</p></div>'+
        '<div class="tablewrap foldertable"><table><thead><tr>'+''.join('<th>'+jesc(x)+'</th>' for x in
        ['フォルダ','ファイル数 直下/配下','平均LUFS 直下/配下','サンプルレート（直下）','形式（直下）',
         'ビット深度（直下）','ビットレート（直下）','再生時間 直下/配下','要確認 直下/配下'])+
        '</tr></thead><tbody>'+''.join(overview)+'</tbody></table></div>'+
        '<div class="sectionhead"><h2>各フォルダの詳細</h2><p class="muted small">クリックすると全指標を展開</p></div>'+
        ''.join(details)
    )
    return section, select, perfile, ancestry

# Supports the existing folder filter and all-file analysis without expanding
# thousands of player DOM nodes. The JS displays only 24 waveform cards per page.
def player_data(rows, roots, perfile, ancestry):
    tracks=[]
    for i,r in enumerate(rows):
        tracks.append({'id':i, 'name':friendly(r['path'],roots),
                       'format':r['format'], 'seconds':r['duration'],
                       'lufs':r['lufs'] if r['lufs'] is not None and math.isfinite(r['lufs']) else None,
                       'issues':needs_attention(r), 'severity':severity_of(r),
                       'reasons':[{'severity':ISSUE_SEVERITY.get(code,'warning'), 'label':RULE_MESSAGES.get(code,code)} for code in r.get('issue_codes',[])],
                       'wave':compact_wave(r),
                       'direct':perfile.get(i,''), 'ancestors':ancestry.get(i,[]),
                       'status':r['status'], 'playable':r['status'] not in ('読取不可','解析失敗','解析待ち')})
    return tracks


def safe_json(value):
    # Avoid script end-tag injection from adversarial file names/metadata.
    return json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')

CSS = '''
.languagebar{display:flex;align-items:center;justify-content:flex-end;gap:8px;margin:0 0 9px;font-size:12px;color:light-dark(#617185,#9da9b8)}
.languagebar select{min-width:125px;padding:6px 8px;font-size:12px}
:root{color-scheme:light dark;font-family:-apple-system,BlinkMacSystemFont,system-ui,sans-serif;font-size:13px}
*{box-sizing:border-box}body{margin:0;background:light-dark(#f4f6f9,#11161c);color:light-dark(#1a2834,#e2e8f1)}
main{max-width:1560px;margin:0 auto;padding:28px 24px 80px}h1{font-size:23px;letter-spacing:-.03em;margin:0 0 6px}h2{font-size:15px;margin:0}
.muted{color:light-dark(#617185,#9da9b8)}.subtitle{line-height:1.6;overflow-wrap:anywhere;margin:0 0 18px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin:16px 0 19px}
.card,.panel,.tablewrap{background:light-dark(#fff,#1d242d);border:1px solid light-dark(#e0e5ec,#384552);border-radius:12px}
.card{padding:16px}.card .name{font-size:12px;color:light-dark(#657487,#9dacbc)}.card .num{font-size:23px;font-weight:700;letter-spacing:-.03em;margin:5px 0}.card .note{font-size:11px;color:light-dark(#657487,#9dacbc)}
.grids{display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:10px;margin-bottom:20px}.panel{padding:17px}.panel h2{margin-bottom:10px}.panel p{line-height:1.7;margin:5px 0;overflow-wrap:anywhere}
.sectionhead{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin:20px 0 10px}.controls{display:flex;gap:12px;align-items:center;flex-wrap:wrap}
input[type=search],select{border:1px solid light-dark(#c4cfda,#516071);border-radius:7px;padding:9px;color:inherit;background:light-dark(white,#24303b)}
.tablewrap{overflow:auto;max-height:640px}table{border-collapse:collapse;width:100%;min-width:1650px;font-size:12px}th{position:sticky;top:0;background:light-dark(#eff2f6,#26313c);text-align:left;white-space:nowrap;z-index:2}th,td{padding:9px 10px;border-bottom:1px solid light-dark(#e9edf2,#343e49);vertical-align:top}td{white-space:nowrap}td:first-child{min-width:260px;max-width:450px;white-space:normal;overflow-wrap:anywhere}tr:hover{background:light-dark(#f7f9fd,#293440)}tr[hidden]{display:none!important}
.ok{color:#219b70}.bad{color:#d85d63}.warn{color:#c88a2c}.info{color:light-dark(#427db4,#9ac7ff)}.pill{padding:3px 7px;border-radius:6px;background:light-dark(#f0f2f5,#2e3a46);display:inline-block}.pill.bad{background:light-dark(#ffe8e5,#502f30)}.pill.warn{background:light-dark(#fff0d6,#483b27)}.pill.info{background:light-dark(#e6f1ff,#253a4b)}.pill.ok{background:light-dark(#e7f7ef,#203c32)}
.small{font-size:12px;line-height:1.7}.footer{font-size:12px;line-height:1.7;color:light-dark(#647488,#a1acb8)}.banner{padding:12px 15px;background:light-dark(#e6eefb,#26364a);border-radius:10px;margin-bottom:18px}.banner progress{display:block;width:100%;margin-top:9px}
a{color:light-dark(#126aba,#87b7fa)}details summary{cursor:pointer}code{overflow-wrap:anywhere}
.foldertable{max-height:460px}.foldertable table{min-width:1220px}.foldertable td:first-child{min-width:220px}
.folderdetail{background:light-dark(#fff,#1d242d);border:1px solid light-dark(#e0e5ec,#384552);border-radius:12px;margin:10px 0;scroll-margin-top:14px}
.folderdetail>summary{padding:15px 18px;list-style:disclosure-closed;overflow-wrap:anywhere}
.folderdetail[open]>summary{border-bottom:1px solid light-dark(#e0e5ec,#384552)}
.folderinner{padding:5px 18px 20px}.folderinner h3{font-size:14px;margin:18px 0 8px}
.folderinner .card{padding:12px}.folderinner .card .num{font-size:18px}
.folderactions{display:flex;gap:18px;flex-wrap:wrap;padding-top:12px}.small{color:inherit}
.players{padding:18px;margin:18px 0 22px;border-radius:12px;background:light-dark(#fff,#1d242d);border:1px solid light-dark(#e0e5ec,#384552)}
.players .head{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-bottom:12px}
.playerlist{display:grid;gap:9px}.playerrow{border-radius:10px;border:1px solid light-dark(#e4eaf1,#41505d);padding:11px 13px;background:light-dark(#f9fbfe,#202b36)}
.playerrow.active{border-color:#4ca2e3}.playertop{display:flex;align-items:center;gap:10px;min-width:0;margin-bottom:4px}
.playername{font-weight:650;flex:1;overflow-wrap:anywhere;min-width:0}.playermeta{font-size:11px;white-space:nowrap;color:light-dark(#647488,#a1acb8)}
.quality-reasons{display:flex;align-items:center;flex-wrap:wrap;gap:6px;margin:2px 0 8px;font-size:11px}.quality-reasons .reason{padding:2px 7px;border-radius:6px;background:light-dark(#eff3f8,#34404c);color:light-dark(#425467,#cad6e4)}
.wavecanvas{display:block;width:100%;height:54px;cursor:pointer;touch-action:manipulation;border-radius:5px}
.wavecanvas:focus-visible{outline:2px solid #438dd9}.playbutton,.pagebutton{border:1px solid light-dark(#bfccd9,#536478);border-radius:8px;background:light-dark(#ecf4fc,#334557);color:inherit;cursor:pointer;padding:7px 12px;font-weight:650}
.playbutton{min-width:52px}.playbutton:disabled{cursor:default;opacity:.5}.playerbottom{display:flex;justify-content:space-between;gap:8px;align-items:center;flex-wrap:wrap}
.playerbottom .time{font-variant-numeric:tabular-nums;font-size:12px}.playerstatus{font-size:11px;color:light-dark(#647488,#a1acb8)}
.pager{display:flex;gap:10px;justify-content:flex-end;align-items:center;margin-top:12px}.playerempty{padding:18px;color:light-dark(#647488,#a1acb8)}
#playerSearch{min-width:170px}.players .controls{gap:8px}.playerhelp{font-size:11px;color:light-dark(#647488,#a1acb8)}

'''
JS = r'''
function updateRows(){
  const q=document.getElementById('search').value.toLowerCase();
  const scope=document.getElementById('scope').value;
  const folder=document.getElementById('folderFilter').value;
  const mode=document.getElementById('folderMode').value;
  let shown=0;
  for(const tr of document.querySelectorAll('#filebody tr')){
    const hit=tr.textContent.toLowerCase().includes(q);
    const state=scope==='all'||(scope==='issues'&&tr.dataset.issues==='true')||(scope==='errors'&&tr.dataset.errors==='true')||(scope==='info'&&tr.dataset.info==='true');
    const place=folder==='all'||(mode==='direct'?tr.dataset.direct===folder:(' '+tr.dataset.ancestors+' ').includes(' '+folder+' '));
    tr.hidden=!(hit&&state&&place);
    if(!tr.hidden)shown++;
  }
  document.getElementById('shown').textContent=shown;
}
function showFolder(id,mode){
  document.getElementById('folderFilter').value=String(id);
  document.getElementById('folderMode').value=mode;
  updateRows();
}
// Audio Folder Inspector v4: exactly one <audio> element for all rows.
(() => {
  const data = (typeof AFI_TRACKS !== 'undefined' && Array.isArray(AFI_TRACKS)) ? AFI_TRACKS : [];
  const audio = document.getElementById('globalAudio');
  const list = document.getElementById('playerList');
  if (!audio || !list || !data.length) return;
  const base = typeof AFI_BASE === 'string' ? AFI_BASE : '';
  const PAGE_SIZE = 24;
  let page=0, current=null, serial=0, proxy=false, pendingSeek=null;
  let visible=[], canvasMap=new Map(), drawing=false;
  const $=id=>document.getElementById(id);
  const $search=$('playerSearch'), $folder=$('playerFolder'), $scope=$('playerScope'), $mode=$('playerMode');
  const fmt=s=>{const t=Math.max(0,Math.floor(Number(s)||0));return `${Math.floor(t/3600)?`${Math.floor(t/3600)}:`:''}${String(Math.floor(t/60)%60).padStart(2,'0')}:${String(t%60).padStart(2,'0')}`};
  const track=id=>data[id];
  function status(id,message){const el=$('ps-'+id);if(el){el.textContent=message||'';if(window.AFI_LOCALE)window.AFI_LOCALE.translateDOM(el);}}
  function setButtonState(){
    document.querySelectorAll('.playbutton[data-id]').forEach(btn=>{
      const id=Number(btn.dataset.id);
      btn.textContent=(id===current && !audio.paused) ? '❚❚' : '▶';
      btn.setAttribute('aria-label',(id===current && !audio.paused?'一時停止: ':'再生: ')+track(id).name);
    });
    requestDraw();
    if(window.AFI_LOCALE)window.AFI_LOCALE.translateDOM(list);
  }
  function activeCard(){
    document.querySelectorAll('.playerrow').forEach(el=>el.classList.toggle('active',Number(el.dataset.id)===current));
  }
  function setClock(id, now){const el=$('pt-'+id);if(el)el.textContent=fmt(now)+' / '+fmt(track(id).seconds);}
  function drawWave(canvas,t){
    if(!canvas||!canvas.isConnected)return;
    const bounds=canvas.getBoundingClientRect();const w=Math.max(1,Math.round(bounds.width));const h=54;
    const dpr=Math.min(2,window.devicePixelRatio||1);
    canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);
    const ctx=canvas.getContext('2d');if(!ctx)return;ctx.scale(dpr,dpr);
    ctx.clearRect(0,0,w,h);
    const selected=t.id===current;
    const end=(selected && Number.isFinite(audio.duration) && audio.duration>0) ? audio.duration : (t.seconds||0);
    const position=(selected&&end>0) ? Math.min(1,Math.max(0, (audio.currentTime||0)/end)) : 0;
    const dark=window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    const back=dark?'#60768c':'#91a8bf',played=dark?'#73cdff':'#217bc2';
    const values=t.wave?Uint8Array.from(atob(t.wave),x=>x.charCodeAt(0)):null;
    if(!values||!values.length){ctx.strokeStyle=back;ctx.beginPath();ctx.moveTo(0,h/2);ctx.lineTo(w,h/2);ctx.stroke();return;}
    const step=2.5;
    for(let x=0;x<w;x+=step){
      const index=Math.min(values.length-1,Math.floor((x/w)*values.length));
      const amp=Math.max(1.5,values[index]/255*(h*.45));
      ctx.fillStyle= x/w<=position ? played : back;
      ctx.fillRect(x,h/2-amp,Math.max(1,step-0.9),amp*2);
    }
    if(selected && position>0){ctx.fillStyle=played;ctx.fillRect(Math.min(w-1,position*w),0,1.5,h);}
  }
  function requestDraw(){
    if(drawing)return;drawing=true;
    requestAnimationFrame(()=>{
      drawing=false;
      for(const [id,canvas] of canvasMap)drawWave(canvas,track(id));
    });
  }
  function matches(){
    const q=$search.value.trim().toLocaleLowerCase();const f=$folder.value,m=$mode.value,s=$scope.value;
    return data.filter(t=>t.name.toLocaleLowerCase().includes(q) &&
      (s==='all'||(s==='issues'&&t.issues)||(s==='info'&&t.severity==='info')||(s==='errors'&&t.severity==='error')) &&
      (f==='all'||(m==='direct'?String(t.direct)===f:t.ancestors.map(String).includes(f))));
  }
  function renderPlayers(){
    visible=matches();const max=Math.max(0,Math.ceil(visible.length/PAGE_SIZE)-1);
    page=Math.min(page,max);canvasMap.clear();list.replaceChildren();
    if(!visible.length){const e=document.createElement('div');e.className='playerempty';e.textContent='条件に一致する音声がありません。';list.append(e);}
    else for(const t of visible.slice(page*PAGE_SIZE,(page+1)*PAGE_SIZE)){
      const card=document.createElement('article');card.className='playerrow';card.dataset.id=t.id;
      const top=document.createElement('div');top.className='playertop';
      const play=document.createElement('button');play.type='button';play.className='playbutton';play.dataset.id=t.id;play.textContent='▶';play.disabled=!t.playable;
      play.addEventListener('click',()=>toggle(t.id));
      const name=document.createElement('div');name.className='playername';name.textContent=t.name;
      const info=document.createElement('span');info.className='playermeta';info.textContent=t.format+' · '+(t.lufs==null?'LUFS —':t.lufs.toFixed(1)+' LUFS');
      top.append(play,name,info);
      const quality=document.createElement('div');quality.className='quality-reasons';
      const state=document.createElement('span');state.className='pill '+({error:'bad',warning:'warn',info:'info',ok:'ok'}[t.severity]||'');
      state.textContent=({error:'エラー',warning:'注意',info:'情報',pending:'解析待ち',ok:'OK'}[t.severity]||'OK');
      quality.append(state);
      for(const reason of (t.reasons||[])){const el=document.createElement('span');el.className='reason';el.textContent=reason.label;quality.append(el);}
      const wave=document.createElement('canvas');wave.className='wavecanvas';wave.setAttribute('role','slider');wave.tabIndex=0;
      wave.setAttribute('aria-label','シーク位置 '+t.name);wave.title='クリックしてその位置から再生';
      wave.addEventListener('pointerdown',e=>{
        const r=wave.getBoundingClientRect();if(r.width<1)return;
        wave.setPointerCapture?.(e.pointerId);
        const fraction=Math.min(1,Math.max(0,(e.clientX-r.left)/r.width));
        seekTrack(t.id,fraction);
      });
      wave.addEventListener('pointermove',e=>{
        if(!(e.buttons&1)||e.pointerId==null)return;
        const r=wave.getBoundingClientRect();if(r.width<1)return;
        const fraction=Math.min(1,Math.max(0,(e.clientX-r.left)/r.width));
        seekTrack(t.id,fraction);
      });
      wave.addEventListener('keydown',e=>{
        if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
        e.preventDefault();
        const dur=t.seconds||audio.duration||0;
        let pos=current===t.id?audio.currentTime:0;
        if(e.key==='Home')pos=0;else if(e.key==='End')pos=dur;
        else pos+=e.key==='ArrowLeft'?-5:5;
        seekTrack(t.id,Math.max(0,Math.min(1,dur>0?pos/dur:0)));
      });
      const bottom=document.createElement('div');bottom.className='playerbottom';
      const clock=document.createElement('span');clock.className='time';clock.id='pt-'+t.id;clock.textContent='0:00 / '+fmt(t.seconds);
      const msg=document.createElement('span');msg.className='playerstatus';msg.id='ps-'+t.id;
      if(!t.playable)msg.textContent='再生不可／解析失敗';
      bottom.append(clock,msg);card.append(top,quality,wave,bottom);list.append(card);canvasMap.set(t.id,wave);
    }
    $('playerCount').textContent=visible.length+'件';
    $('playerPage').textContent=`${visible.length?page+1:0} / ${Math.max(1,Math.ceil(visible.length/PAGE_SIZE))}`;
    $('playerPrev').disabled=page<=0;$('playerNext').disabled=page>=max;
    activeCard();setButtonState();
  }
  function resetAudio(){audio.pause();audio.removeAttribute('src');audio.load();}
  async function loadProxy(id, ticket){
    if(!base){status(id,'試聴にはQuick Actionを再実行してください');return;}
    status(id,'試聴音声を準備中（初回のみ変換）…');
    try{
      while(ticket===serial){
        const resp=await fetch(`${base}/preview/${id}`,{cache:'no-store'});
        if(!resp.ok)throw new Error('試聴準備サービスへ接続できません');
        const result=await resp.json();
        if(ticket!==serial)return;
        if(result.state==='ready'){
          proxy=true;status(id,'');
          audio.src=`${base}/proxy/${id}`;
          audio.load();
          await playMedia(ticket,id);
          return;
        }
        if(result.state==='error')throw new Error(result.message||'変換に失敗しました');
        await new Promise(resolve=>setTimeout(resolve,850));
      }
    }catch(err){if(ticket===serial)status(id,String(err.message||err));}
  }
  async function playMedia(ticket,id){
    if(ticket!==serial)return;
    try{await audio.play();status(id,'');}
    catch(err){
      if(ticket!==serial)return;
      if(!proxy && err.name!=='NotAllowedError')return loadProxy(id,ticket);
      status(id,err.name==='NotAllowedError'?'もう一度 ▶ を押すと再生します':String(err.message||err));
    }finally{setButtonState();}
  }
  function seekTrack(id,fraction){
    const t=track(id);const duration=t.seconds||0;
    pendingSeek=Math.min(duration,Math.max(0,duration*fraction));
    if(current!==id){start(id);return;}
    if(audio.readyState>=1 && Number.isFinite(audio.duration) && audio.duration>0){
      try{audio.currentTime=Math.min(audio.duration-.01,Math.max(0,pendingSeek));pendingSeek=null;}catch{}
    }
    setClock(id,pendingSeek||audio.currentTime);requestDraw();
  }
  function start(id){
    if(!track(id)?.playable)return;
    const previous=current;serial++;const ticket=serial;
    if(previous!==null)status(previous,'');
    resetAudio();current=id;proxy=false;activeCard();setButtonState();
    if(!base){status(id,'再生サービスがありません。FinderからQuick Actionを再実行してください');return;}
    const ext=track(id).format.toLowerCase();
    const transcode=new Set(['aif','aiff','aifc','caf','wv','ape','wma','mka','dsf','dff','bwf']);
    if(transcode.has(ext))loadProxy(id,ticket);
    else {audio.src=`${base}/media/${id}`;audio.load();playMedia(ticket,id);}
  }
  function toggle(id){
    if(current===id){
      if(audio.paused){playMedia(serial,id);}else{audio.pause();setButtonState();}
    }else{pendingSeek=null;start(id);}
  }
  audio.addEventListener('loadedmetadata',()=>{
    if(current===null)return;
    if(pendingSeek!==null && Number.isFinite(audio.duration)){
      try{audio.currentTime=Math.max(0,Math.min(Math.max(0,audio.duration-.01),pendingSeek));}catch{}
      pendingSeek=null;
    }
  });
  audio.addEventListener('error',()=>{
    if(current===null||!audio.error)return;
    const id=current;const ticket=serial;
    if(!proxy)loadProxy(id,ticket);
    else status(id,'このファイルはプレビューできませんでした');
  });
  audio.addEventListener('timeupdate',()=>{
    if(current===null)return;
    setClock(current,audio.currentTime);const canvas=canvasMap.get(current);
    if(canvas)drawWave(canvas,track(current));
  });
  audio.addEventListener('play',setButtonState);
  audio.addEventListener('pause',setButtonState);
  audio.addEventListener('ended',()=>{
    setButtonState();if(current!==null)status(current,'再生終了');
  });
  for(const el of [$search,$folder,$mode,$scope])el.addEventListener(el===$search?'input':'change',()=>{page=0;renderPlayers();});
  $('playerPrev').addEventListener('click',()=>{page--;renderPlayers();});
  $('playerNext').addEventListener('click',()=>{page++;renderPlayers();});
  window.addEventListener('resize',requestDraw);
  window.addEventListener('afi-language-change',renderPlayers);
  // While the report is open, keep the loopback server alive. The server exits
  // after 20min without a live report, leaving no permanent daemon behind.
  if(base)setInterval(()=>fetch(`${base}/ping`,{cache:'no-store'}).catch(()=>{}),60000);
  renderPlayers();
})();

'''



# CSV column identifiers are stable English for cross-language workflows.
CSV_ISSUES_EN = {
    'rate_mismatch': 'Sample rate mismatch', 'sample_count_mismatch': 'Sample count mismatch',
    'depth_mismatch': 'Bit depth mismatch', 'format_mismatch': 'Format mismatch',
    'channel_mismatch': 'Channel count mismatch', 'silent': 'Digital silence',
    'lufs_unavailable': 'LUFS unavailable (short/gated)', 'effective_silence': 'Effectively silent audio',
    'lufs_range': 'LUFS outside allowed range', 'lufs_outlier': 'LUFS far from median',
    'true_peak_high': 'True peak above limit', 'clip_suspected': 'Possible clipping (sample peak)',
    'long_head': 'Long leading silence', 'long_tail': 'Long trailing silence',
    'dc_offset': 'High DC offset', 'imbalance': 'Stereo imbalance',
    'dual_mono': 'Dual mono in stereo',
}
CSV_STATUS_EN = {
    'OK':'OK', '要確認':'Flagged', '読取不可':'Unreadable',
    '解析失敗':'Analysis failed', '解析待ち':'Pending',
}

CSV_HEADERS_EN = {
    'ファイル':'File', 'パス':'Path', 'サイズB':'Size (bytes)',
    '形式':'Format', 'コーデック':'Codec', 'サンプルレートHz':'Sample rate (Hz)',
    'ビット深度':'Bit depth', 'チャンネル数':'Channels', 'チャンネル配置':'Channel layout',
    'ビットレートbps':'Bit rate (bps)', '再生時間秒':'Duration (s)',
    'デコードサンプル数':'Decoded sample count', '先頭無音秒':'Leading silence (s)',
    '末尾無音秒':'Trailing silence (s)', '左右RMS差dB（L-R）':'L-R RMS difference (dB)',
    '左右差分RMS相対dB':'L-R difference RMS relative (dB)',
    'ch別 RMS dB':'Per-channel RMS (dB)', 'ch別 DC Offset':'Per-channel DC offset',
    '状態':'Status', '解析状態':'Analysis status', '警告':'Warnings',
}
FOLDER_CSV_HEADERS_EN = [
    'Folder', 'Folder path', 'Direct files', 'Including subfolders: files',
    'Direct analyzed', 'Including subfolders: analyzed', 'Direct mean LUFS',
    'Including subfolders: mean LUFS', 'Direct median LUFS',
    'Including subfolders: median LUFS', 'Direct minimum LUFS',
    'Direct maximum LUFS', 'Direct LUFS standard deviation', 'Direct mean LRA',
    'Direct max True Peak (dBTP)', 'Direct max Sample Peak (dBFS)',
    'Direct flagged', 'Including subfolders: flagged', 'Direct read/decode errors',
    'Direct digitally silent', 'Direct effectively silent', 'Direct BWF/iXML',
    'Direct duration (s)', 'Including subfolders: duration (s)',
    'Direct file size (bytes)', 'Including subfolders: file size (bytes)',
    'Direct formats', 'Direct codecs', 'Direct sample rates', 'Direct bit depths',
    'Direct channels', 'Direct bit rates', 'Direct duration-weighted bit rate (bps)',
    'Direct warnings', 'Direct info files', 'Direct warning files', 'Direct error files',
    'Including subfolders: info files', 'Including subfolders: warning files', 'Including subfolders: error files',
]


def csv_cell(value):
    # Prevent spreadsheet formula execution on imported file name / metadata columns.
    txt = '' if value is None else str(value)
    if txt.lstrip().startswith(('=', '+', '-', '@', '\t', '\r')):
        return "'" + txt
    return txt


def export_csv(rows, roots, destination):
    fields = [
        ('ファイル','name'),('パス','path'),('サイズB','size'),('形式','format'),('コーデック','codec'),
        ('サンプルレートHz','sr'),('ビット深度','depth'),('チャンネル数','channels'),('チャンネル配置','channel_layout'),
        ('ビットレートbps','bitrate'),('再生時間秒','duration'),('デコードサンプル数','sample_count'),
        ('Integrated LUFS','lufs'),('LUFS-LRA','lra'),('True Peak dBTP','true_peak'),('Sample Peak dBFS','sample_peak'),
        ('先頭無音秒','lead_silence'),('末尾無音秒','tail_silence'),('左右RMS差dB（L-R）','stereo_balance_db'),
        ('左右差分RMS相対dB','stereo_difference_db'),('ch別 RMS dB','channel_rms'),('ch別 DC Offset','channel_dc'),('Dual Mono','dual_mono'),('DC offset（%FS）','dc_pct'),
        ('BWF Description','bwf_description'),('BWF Originator Reference','bwf_originator_reference'),
        ('BWF Originator','bwf_originator'),('BWF Origination','bwf_origination'),
        ('BWF Time Reference（samples）','bwf_time_reference_samples'),('BWF Time Reference','bwf_time_reference_tc'),
        ('iXML Project','ixml_project'),('iXML Tape','ixml_tape'),('iXML Scene','ixml_scene'),
        ('iXML Take','ixml_take'),('iXML Note','ixml_note'),('iXML UID','ixml_file_uid'),
        ('iXML Timecode','ixml_timecode'),('iXML Track Names','ixml_track_names'),('状態','status'),('解析状態','analysis_status'),('警告','warning'),
        ('Severity','severity'),('Reasons','reason_labels')]
    with destination.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow([CSV_HEADERS_EN.get(k,k) for k,_ in fields])
        for r in rows:
            decorated = dict(r, name=friendly(r['path'], roots),
                             channel_rms=json.dumps(r.get('channel_rms',[])), channel_dc=json.dumps(r.get('channel_dc',[])),
                             dc_pct=abs(r['dc_offset'])*100 if r['dc_offset'] is not None else None,
                             warning=' / '.join([CSV_ISSUES_EN[c] for c in r.get('issue_codes',[]) if c in CSV_ISSUES_EN] +
                                               [w for w in r['warnings'] if w not in RULE_MESSAGES.values()]))
            decorated['severity'] = severity_of(r).upper()
            decorated['reason_labels'] = ' / '.join(CSV_ISSUES_EN.get(c,c) for c in r.get('issue_codes',[]))
            decorated['analysis_status'] = CSV_STATUS_EN.get(r['status'], r['status'])
            decorated['status'] = {'ok':'OK','info':'Info','warning':'Warning','error':'Error','pending':'Pending'}[severity_of(r)]
            untrusted = {'name','path','bwf_description','bwf_originator_reference','bwf_originator','bwf_origination','bwf_time_reference_tc',
                         'ixml_project','ixml_tape','ixml_scene','ixml_take','ixml_note',
                         'ixml_file_uid','ixml_timecode','ixml_track_names','warning','reason_labels'}
            writer.writerow([(csv_cell(decorated.get(key)) if key in untrusted else ('' if decorated.get(key) is None else decorated[key]))
                             for _, key in fields])


def render(rows, roots, output, csvfile, config, completed, done, foldercsv=None, player_base=None):
    groups = group_folders(rows, roots)
    folder_section, folder_options, perfile, ancestry = render_folder_sections(rows, roots, groups)
    observed = [r for r in rows if r['status'] != '解析待ち']
    metadata = [r for r in observed if r['sr'] is not None]
    ok = [r for r in observed if r['status'] not in ('読取不可','解析失敗','要確認') and r.get('lufs_valid', True) and r['lufs'] is not None and math.isfinite(r['lufs'])]
    values = [r['lufs'] for r in ok]
    avg = statistics.mean(values) if values else None
    median = statistics.median(values) if values else None
    minimum = min(values) if values else None
    maximum = max(values) if values else None
    std = statistics.stdev(values) if len(values) >= 2 else (0.0 if len(values) == 1 else None)
    duration = sum(r['duration'] for r in metadata if r['duration'] is not None)
    size = sum(r['size'] for r in observed if r['size'] is not None)
    silents = sum(bool(r['is_silent']) for r in observed)
    effective_silents = sum(bool(r.get('is_effective_silent')) for r in observed)
    violations = [r for r in observed if needs_attention(r)]
    invalid = [r for r in observed if severity_of(r) == 'error']
    info_count = sum(severity_of(r) == 'info' for r in observed)
    warning_count = sum(severity_of(r) == 'warning' for r in observed)
    peak_values = [r['true_peak'] for r in observed if r['true_peak'] is not None and math.isfinite(r['true_peak'])]
    peaks = max(peak_values) if peak_values else None
    has_bwf = sum(r['bwf_time_reference_samples'] is not None or any(r.get(x) for x in ('ixml_project','ixml_scene','ixml_take','ixml_file_uid')) for r in observed)
    grouped = Counter(code for r in observed for code in r['issue_codes'])
    cards = [
        ('音声ファイル', f'{len(rows):,}', f'解析済み {completed:,}'),
        ('平均 LUFS-I', db_label(avg), f'{len(values)}件の算術平均'),
        ('中央値 / 標準偏差', (db_label(median, digs=1)+' / '+db_label(std, digs=1)), 'LUFS / LU'),
        ('最小 / 最大 LUFS', db_label(minimum, digs=1)+' / '+db_label(maximum, digs=1), '有効値のみ'),
        ('最大 True Peak', db_label(peaks), 'dBTP'),
        ('総再生時間', dur_label(duration), '取得できたファイルの合計'),
        ('総ファイル容量', size_label(size), '解析済みファイル'),
        ('要確認ファイル', str(len(violations)), f'注意 {warning_count}件 / エラー {len(invalid)}件 / 情報 {info_count}件'),
        ('無音 / 実質無音', f'{silents} / {effective_silents}', '完全な無音 / 閾値以下（無音含む）'),
        ('BWF / iXML', str(has_bwf), 'メタデータ検出ファイル'),
    ]
    cards_html = ''.join(f'<article class="card"><div class="name">{jesc(x)}</div><div class="num">{jesc(y)}</div><div class="note">{jesc(z)}</div></article>' for x,y,z in cards)
    bitrates = [r for r in metadata if r.get('bitrate') is not None and r.get('duration') is not None and r['duration'] > 0]
    weighted = (sum(r['bitrate'] * r['duration'] for r in bitrates)/sum(r['duration'] for r in bitrates)) if bitrates else None
    panels = [
        ('ファイル形式', dist((r['format'] for r in metadata))),
        ('コーデック', dist((r['codec'] for r in metadata))),
        ('サンプルレート', dist((r['sr'] for r in metadata), rate_label)),
        ('ビット深度', dist((r['depth'] for r in metadata))),
        ('チャンネル数・配置', dist((f"{r['channels']}ch / {r['channel_layout']}" for r in metadata))),
        ('ビットレート', dist((f"{round(r['bitrate']/1000)} kb/s" if r['bitrate'] else '不明' for r in metadata)) +
         (f' / 時間加重平均 約{weighted/1000:.0f} kb/s' if weighted else '')),
        ('品質チェック', ('<div>' + ''.join(f'<p><span class="pill {issue_class(k)}">{n}件</span> {jesc(SEVERITY_JA.get(ISSUE_SEVERITY.get(k, "warning")))} · {jesc(RULE_MESSAGES.get(k,k))}</p>' for k,n in grouped.most_common()) + '</div>') if grouped else '問題検出なし'),
    ]
    panels_html = ''.join('<article class="panel"><h2>'+jesc(title)+'</h2>'+ (v if title == '品質チェック' and grouped else '<p>'+jesc(v)+'</p>') +'</article>' for title,v in panels)
    trs = []
    for idx, r in enumerate(rows):
        severity = severity_of(r)
        flagged = severity in ('warning', 'error')
        error = severity == 'error'
        information = severity == 'info'
        scls = status_class(severity)
        state = SEVERITY_JA[severity]
        note = ' / '.join(issue_detail(r))
        if not note and r.get('warnings'): note = ' / '.join(r['warnings'])
        fields = [
            friendly(r['path'], roots), size_label(r['size']), r['format'], r['codec'], rate_label(r['sr']), r['depth'],
            (f"{r['channels']} / {r['channel_layout']}" if r['channels'] else '—'),
            (f"{'約' if r['bitrate_estimated'] else ''}{r['bitrate']/1000:.0f}" if r['bitrate'] else '—'),
            dur_label(r['duration']), str(r['sample_count']) if r['sample_count'] is not None else '—',
            db_label(r['lufs']), db_label(r['lra']), db_label(r['true_peak']), db_label(r['sample_peak']),
            db_label(r['lead_silence'],digs=2), db_label(r['tail_silence'],digs=2),
            db_label(r['stereo_balance_db']), db_label(r['stereo_difference_db']),
            ('Yes' if r['dual_mono'] else 'No' if r['dual_mono'] is False else '—'),
            db_label(r['dc_offset']*100, digs=3) if r['dc_offset'] is not None else '—',
            r['bwf_origination'] or '—',
            str(r['bwf_time_reference_samples']) if r['bwf_time_reference_samples'] is not None else '—',
            r['bwf_time_reference_tc'] or '—',
            r['bwf_originator'] or '—', r['bwf_description'] or '—', r['bwf_originator_reference'] or '—',
            r['ixml_project'] or '—', r['ixml_scene'] or '—', r['ixml_take'] or '—',
            r['ixml_tape'] or '—', r['ixml_timecode'] or '—', r['ixml_track_names'] or '—',
            r['ixml_note'] or '—', r['ixml_file_uid'] or '—',
        ]
        cells = ''.join(f'<td title="{jesc(x) if isinstance(x,str) and len(x)>40 else ""}">{jesc(x)}</td>' for x in fields)
        direct_id = perfile.get(idx, '')
        ancestor_ids = ' '.join(ancestry.get(idx, []))
        trs.append(f'<tr data-issues="{str(flagged).lower()}" data-errors="{str(error).lower()}" data-info="{str(information).lower()}" data-direct="{direct_id}" data-ancestors="{ancestor_ids}">'+cells+
                   f'<td><span class="pill {scls}">{jesc(state)}</span></td><td title="{jesc(note)}">{jesc(note)}</td></tr>')
    headers = ['ファイル','サイズ','形式','コーデック','Sample Rate','bit depth','ch / layout','kb/s','長さ','サンプル数',
               'LUFS-I','LRA','True Peak','Sample Peak','頭無音秒','末尾無音秒','L-R RMS dB','差分RMS dB',
               'Dual Mono','DC Offset %','BWF日時','BWF time ref (sample)','BWF time ref (time)','BWF Originator','BWF Description','BWF Originator Reference',
               'iXML Project','Scene','Take','Tape','Timecode','Track','Note','UID','状態','警告']
    # Keep a compact one-pass waveform cache in the report. It contains no audio.
    tracks = player_data(rows,roots,perfile,ancestry) if done else []
    track_json = safe_json(tracks)
    base_json = safe_json(player_base or '')
    player_html = f'''<section class="players" id="players"><div class="head"><h2>波形プレーヤー <span class="muted" style="font-size:12px">（音声は再生時のみ読み込み）</span></h2>
      <div class="controls"><select id="playerFolder" aria-label="フォルダ"><option value="all">全フォルダ</option>{folder_options}</select>
      <select id="playerMode" aria-label="フォルダの範囲"><option value="subtree">サブフォルダ含む</option><option value="direct">直下のみ</option></select>
      <select id="playerScope" aria-label="状態"><option value="all">全ファイル</option><option value="issues">要確認のみ</option><option value="info">情報のみ</option><option value="errors">エラーのみ</option></select>
      <input id="playerSearch" type="search" placeholder="ファイル名で検索" aria-label="音声ファイルを検索"></div></div>
      <div class="playerhelp">波形をクリック／ドラッグしてシーク。別ファイルを再生すると、前の音声は停止します。1ページ24件を表示します。</div>
      <div class="playerlist" id="playerList"></div><div class="pager"><span id="playerCount">0件</span><button class="pagebutton" id="playerPrev">前へ</button><span id="playerPage"></span><button class="pagebutton" id="playerNext">次へ</button></div>
      <audio id="globalAudio" preload="none" playsinline style="display:none"></audio></section>'''
    if not done:
        player_html = '<section class="players"><h2>波形プレーヤー</h2><p class="muted">解析完了後に表示します。元音声は書き換えません。</p></section>'
    player_init = f'<script>const AFI_TRACKS={track_json};const AFI_BASE={base_json};</script>'
    title = '音声フォルダ情報 — 品質チェック'
    refresh = f'<meta http-equiv="refresh" content="{REFRESH}">' if not done else ''
    progress = (f'<div class="banner">解析中: {completed} / {len(rows)} ファイル <progress max="{len(rows)}" value="{completed}"></progress>完了まで自動更新します。</div>' if not done else '')
    i18n_js = (Path(__file__).with_name('afi_i18n.js')).read_text(encoding='utf-8')
    language_default = safe_json(config['ui_language'])
    mac_language = safe_json(system_language())
    html_doc = f'''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">{refresh}<title>{jesc(title)}</title><style>{CSS}</style></head>
<body><main><div class="languagebar"><label id="afiLangLabel" for="afiLang">Language</label><select id="afiLang" aria-label="Report language"></select></div><h1>{jesc(title)}</h1><p class="subtitle muted"><span data-afi-untranslated>{jesc(' / '.join(roots))}</span><br>作成: {jesc(dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}・元音声は変更しません</p>
{progress}<section class="cards">{cards_html}</section><section class="grids">{panels_html}</section>
{folder_section}
{player_html}
<div class="sectionhead" id="filelist"><h2>全ファイル一覧</h2><div class="controls"><a href="{quote(csvfile.name)}">ファイル別CSV</a> <a href="{quote(foldercsv.name) if foldercsv else '#'}">フォルダ別CSV</a><select id="folderFilter" onchange="updateRows()"><option value="all">全フォルダ</option>{folder_options}</select><select id="folderMode" onchange="updateRows()"><option value="subtree">サブフォルダ含む</option><option value="direct">直下のみ</option></select><select id="scope" onchange="updateRows()"><option value="all">全ファイル</option><option value="issues">要確認のみ</option><option value="info">情報のみ</option><option value="errors">エラーのみ</option></select><input id="search" type="search" placeholder="ファイル名や値で検索" oninput="updateRows()">表示: <b id="shown">{len(rows)}</b>件</div></div>
<div class="tablewrap"><table><thead><tr>{''.join('<th>'+jesc(h)+'</th>' for h in headers)}</tr></thead><tbody id="filebody">{''.join(trs)}</tbody></table></div>
<details class="panel" style="margin-top:16px"><summary>測定方法と判定基準（クリックで展開）</summary>
<div class="small"><p data-afi-i18n-key="measurement"></p>
<p data-afi-i18n-key="lufs_policy"></p>
<p data-afi-i18n-key="quality_policy"></p>
<p><span data-afi-i18n-key="configuration_label"></span> <code data-afi-untranslated>{jesc(CONFIG_FILE)}</code> <span data-afi-i18n-key="configuration_policy"></span></p><pre data-afi-untranslated>{jesc(json.dumps({k:v for k,v in config.items() if not k.startswith('_')},ensure_ascii=False,indent=2))}</pre>
</div></details>
<p class="footer"><span data-afi-i18n-key="waveform_policy"></span><br><span data-afi-i18n-key="report_label"></span> <code data-afi-untranslated>{jesc(output)}</code><br><span data-afi-i18n-key="folder_csv_label"></span> <code data-afi-untranslated>{jesc(foldercsv) if foldercsv else "—"}</code><br><span data-afi-i18n-key="cache_policy"></span></p></main>{player_init}<script>{JS}</script><script>window.AFI_DEFAULT_LANGUAGE={language_default};window.AFI_SYSTEM_LANGUAGE={mac_language};</script><script>{i18n_js}</script></body></html>'''
    # Publish the continuously updating report atomically, so a browser refresh
    # never catches a half-written HTML document.
    temporary = output.with_name(output.name + '.tmp')
    temporary.write_text(html_doc, encoding='utf-8')
    os.replace(temporary, output)


def cache_from_json(row):
    # JSON stores null for -inf; restore strictly for digital silence.
    defaults = blank_row(Path(row['path']))
    defaults.update(row)
    row = defaults
    if row.get('is_silent'):
        row['sample_peak'] = float('-inf')
        row['lufs'] = float('-inf')
        row['true_peak'] = float('-inf') if row.get('true_peak') is None else row['true_peak']
    return row


def sanitize(row):
    def visit(value):
        if isinstance(value, float) and not math.isfinite(value):
            return None
        if isinstance(value, list):
            return [visit(v) for v in value]
        if isinstance(value, dict):
            return {k:visit(v) for k,v in value.items()}
        return value
    return visit(row)


def run(paths):
    if not paths:
        print('Usage: python3 audio_folder_inspector.py FOLDER [FOLDER ...]', file=sys.stderr)
        return 2
    config = config_load()
    ffprobe, ffmpeg = find_tool('ffprobe'), find_tool('ffmpeg')
    if not ffprobe or not ffmpeg:
        notify('Audio Folder Inspector', 'FFmpeg / ffprobe required: brew install ffmpeg', alert=True)
        return 2
    files, roots = selected_audio_paths(paths)
    if not files:
        notify('Audio Folder Inspector', 'No supported audio files in the selected folder', alert=True)
        return 1
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    report = REPORT_DIR / f'audio_report_{dt.datetime.now().strftime("%Y%m%d_%H%M%S")}_{uuid4().hex[:6]}.html'
    csvfile = report.with_suffix('.csv')
    foldercsv = report.with_name(report.stem + '_folders.csv')
    rows = [blank_row(p) for p in files]
    try:
        cache = json.loads(CACHE_FILE.read_text(encoding='utf-8')) if CACHE_FILE.exists() else {}
        if not isinstance(cache, dict):
            cache = {}
    except (OSError, ValueError):
        cache = {}
    export_csv(rows, roots, csvfile)
    export_folder_csv(group_folders(rows, roots), rows, foldercsv)
    player_base = start_player_server(report, files, ffmpeg)
    render(rows, roots, report, csvfile, config, 0, False, foldercsv, player_base)
    opener = '/usr/bin/open' if sys.platform == 'darwin' else shutil.which('xdg-open')
    if opener and os.getenv('AFI_NO_OPEN') != '1':
        try:
            subprocess.Popen([opener, player_base + '/report' if player_base else str(report)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            pass
    start = time.monotonic()
    def analyze(path):
        try:
            key = base_key(path, config)
            saved = cache.get(key)
            if saved and saved.get('status') == 'OK' and saved.get('sample_count') is not None:
                row = cache_from_json(saved)
            else:
                row = measure(probe(path, ffprobe), ffmpeg, config)
            if row['status'] in ('OK','要確認') and row.get('waveform') is None:
                row['waveform'] = waveform_peaks(path, ffmpeg, row['duration'], int(config['waveform_bins']))
            return row, key
        except OSError as exc:
            row = blank_row(path)
            row['status'] = '読取不可'
            row['warnings'].append(str(exc)[:250])
            row['issue_codes'].append('unreadable')
            return row, None
    with ThreadPoolExecutor(max_workers=int(config['worker_count'])) as pool:
        futures = {pool.submit(analyze, file):i for i,file in enumerate(files)}
        for count, future in enumerate(as_completed(futures), 1):
            idx = futures[future]
            r, key = future.result()
            rows[idx] = r
            if key and r['status'] == 'OK':
                cache[key] = sanitize(r)
            if count % 2 == 0 or count == len(files):
                check_rules(rows, config)
                export_csv(rows, roots, csvfile)
                export_folder_csv(group_folders(rows, roots), rows, foldercsv)
                render(rows, roots, report, csvfile, config, count, False, foldercsv, player_base)
    check_rules(rows, config)
    export_csv(rows, roots, csvfile)
    export_folder_csv(group_folders(rows, roots), rows, foldercsv)
    render(rows, roots, report, csvfile, config, len(files), True, foldercsv, player_base)
    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        temp = CACHE_FILE.with_name('cache_v4.'+uuid4().hex[:8]+'.json')
        # Don't save computed warnings so each new config applies fresh rules.
        for r in rows:
            if r['status'] == 'OK':
                rr = dict(r)
                rr['issue_codes'] = [code for code in rr['issue_codes'] if code not in COMPUTED_CODES]
                rr['warnings'] = [w for w in rr['warnings'] if w not in [RULE_MESSAGES[c] for c in COMPUTED_CODES]]
                cache[base_key(Path(rr['path']), config)] = sanitize(rr)
        temp.write_text(json.dumps(cache, ensure_ascii=False, allow_nan=False), encoding='utf-8')
        os.replace(temp, CACHE_FILE)
    except (OSError, ValueError):
        pass
    issues = sum(needs_attention(r) for r in rows)
    notify('Audio Folder Inspector', f'{len(files)} analyzed · {issues} flagged · {int(time.monotonic()-start)}s')
    print(report)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(run(sys.argv[1:]))
    except Exception as exc:
        notify('Audio Folder Inspector — Error', str(exc)[:180], alert=True)
        raise

