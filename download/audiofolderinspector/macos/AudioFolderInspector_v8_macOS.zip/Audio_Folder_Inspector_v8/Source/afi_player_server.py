#!/usr/bin/env python3
"""Loopback-only media streamer for Audio Folder Inspector reports.

Serves a strict manifest allowlist with HTTP Range; converts unsupported codecs
only if the user presses play. Never writes into a source folder.
"""
from __future__ import annotations
import concurrent.futures
import hashlib
import json
import mimetypes
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

IDLE_SECONDS = 20 * 60
PREVIEW_TYPES = {'.aif', '.aiff', '.aifc', '.caf', '.wv', '.ape', '.wma', '.mka', '.dsf', '.dff', '.bwf'}
MIMES = {'.wav':'audio/wav', '.wave':'audio/wav', '.mp3':'audio/mpeg', '.m4a':'audio/mp4',
         '.aac':'audio/aac', '.mp4':'audio/mp4', '.mov':'audio/quicktime', '.flac':'audio/flac',
         '.ogg':'audio/ogg', '.opus':'audio/ogg'}

class PlayerServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False
    def __init__(self, manifest):
        super().__init__(('127.0.0.1', 0), PlayerHandler)
        self.token = manifest['token']
        self.report = Path(manifest['report'])
        self.files = manifest['files']
        self.ffmpeg = manifest['ffmpeg']
        self.config_file = Path(manifest['config_file'])
        self.cache = Path(manifest['cache'])
        self.cache.mkdir(parents=True, exist_ok=True)
        self.jobs = {}
        self.jobs_lock = threading.Lock()
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        self.last_seen = time.monotonic()
    def get_source(self, idx):
        if idx < 0 or idx >= len(self.files):
            return None
        info = self.files[idx]
        p = Path(info['path'])
        try:
            st = p.lstat()
            if p.is_symlink() or not p.is_file() or st.st_size != info['size'] or st.st_mtime_ns != info['mtime_ns']:
                return None
            if st.st_ino != info['ino'] or st.st_dev != info['dev']:
                return None
        except OSError:
            return None
        return p
    def preview_path(self, idx):
        info = self.files[idx]
        sig = (info['path'] + '/' + str(info['size']) + '/' + str(info['mtime_ns'])).encode()
        return self.cache / (hashlib.sha256(sig).hexdigest()[:24] + '.mp3')
    def convert(self, idx, out):
        p = self.get_source(idx)
        if p is None: raise ValueError('元ファイルが変更または削除されています')
        with tempfile.NamedTemporaryFile(dir=self.cache, prefix='conversion_', suffix='.mp3', delete=False) as fp:
            tmp = Path(fp.name)
        try:
            command = [self.ffmpeg, '-hide_banner', '-nostdin', '-loglevel', 'error', '-y',
                       '-i', str(p), '-map', '0:a:0', '-vn', '-sn', '-dn',
                       '-ac', '2', '-ar', '44100', '-c:a', 'libmp3lame', '-b:a', '128k', str(tmp)]
            proc = subprocess.run(command, capture_output=True, text=True, errors='replace')
            if proc.returncode != 0 or not tmp.is_file() or tmp.stat().st_size < 200:
                raise ValueError((proc.stderr or 'プレビュー変換失敗')[-240:])
            os.replace(tmp, out)
        finally:
            tmp.unlink(missing_ok=True)
    def get_preview(self, idx):
        if self.get_source(idx) is None:
            return {'state':'error', 'message':'元ファイルが見つからないか変更されています'}
        out = self.preview_path(idx)
        if out.is_file() and out.stat().st_size > 200:
            return {'state':'ready'}
        with self.jobs_lock:
            future = self.jobs.get(idx)
            if future is None:
                future = self.executor.submit(self.convert, idx, out)
                self.jobs[idx] = future
        if future.done():
            err = future.exception()
            return {'state':'error','message':str(err)[:300]} if err else {'state':'ready'}
        return {'state':'processing'}

class PlayerHandler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, *_): pass
    def do_HEAD(self): self.handle_request(True)
    def do_GET(self): self.handle_request(False)
    def do_POST(self):
        server = self.server
        path = urlsplit(self.path).path
        if path != '/' + server.token + '/language':
            return self.send_error(404)
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            return self.send_error(400)
        if length < 2 or length > 100:
            return self.send_error(413)
        try:
            payload = json.loads(self.rfile.read(length).decode('utf-8'))
            mode = payload['mode']
            if mode not in ('auto','en','ja','fr','de','es','zh-CN','ko'):
                return self.send_error(400)
            target = server.config_file
            config = json.loads(target.read_text(encoding='utf-8'))
            if not isinstance(config, dict):
                return self.send_error(409)
            config['ui_language'] = mode
            config['_afi_language_v6_migrated'] = True
            # Atomic replacement, with user-only permissions.
            import secrets
            temp = target.with_name(target.name + '.' + secrets.token_hex(6) + '.tmp')
            try:
                with temp.open('x', encoding='utf-8') as fp:
                    os.fchmod(fp.fileno(), 0o600)
                    fp.write(json.dumps(config, ensure_ascii=False, indent=2) + '\n')
                os.replace(temp, target)
            finally:
                temp.unlink(missing_ok=True)
            server.last_seen = time.monotonic()
            return self.send_json({'ok': True, 'mode':mode})
        except (OSError, UnicodeError, ValueError, TypeError, KeyError):
            return self.send_error(400)

    def handle_request(self, head=False):
        server = self.server
        path = urlsplit(self.path).path
        prefix = '/' + server.token + '/'
        if not path.startswith(prefix):
            return self.send_error(404)
        server.last_seen = time.monotonic()
        sub = path[len(prefix):]
        if sub == 'report':
            return self.stream_file(server.report, 'text/html; charset=utf-8', head, False)
        if sub == 'ping':
            return self.send_json({'ok':True},head)
        if sub in (server.report.with_suffix('.csv').name,
                   server.report.with_name(server.report.stem+'_folders.csv').name):
            return self.stream_file(server.report.with_name(sub),'text/csv; charset=utf-8',head,False)
        match = re.fullmatch(r'(media|preview|proxy)/(\d+)', sub)
        if not match:
            return self.send_error(404)
        kind, sn = match.groups()
        idx = int(sn)
        source = server.get_source(idx)
        if source is None:
            return self.send_error(410, 'Source missing or modified')
        if kind == 'preview':
            return self.send_json(server.get_preview(idx),head)
        if kind == 'media':
            return self.stream_file(source,MIMES.get(source.suffix.lower(),'application/octet-stream'),head,True)
        out = server.preview_path(idx)
        if not out.is_file():
            return self.send_error(404, 'Preview not ready')
        return self.stream_file(out,'audio/mpeg',head,True)
    def send_json(self, obj, head=False):
        data = json.dumps(obj,ensure_ascii=False).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(data)))
        self.end_headers()
        if not head: self.wfile.write(data)
    def stream_file(self, p, mime, head, ranges):
        try:
            fp = p.open('rb')
            size = p.stat().st_size
        except OSError:
            return self.send_error(404)
        with fp:
            start, end = 0, max(0,size-1)
            partial = False
            if ranges and 'Range' in self.headers:
                raw = self.headers['Range'].strip()
                m = re.fullmatch(r'bytes=(\d*)-(\d*)',raw)
                if not m or size == 0:
                    self.send_response(416)
                    self.send_header('Content-Range',f'bytes */{size}')
                    self.send_header('Content-Length','0')
                    self.end_headers()
                    return
                a,b=m.groups()
                if a:
                    start=int(a);end=int(b) if b else size-1
                elif b:
                    start=max(0,size-int(b))
                else: start=size
                if start>=size or end<start:
                    self.send_response(416)
                    self.send_header('Content-Range',f'bytes */{size}')
                    self.send_header('Content-Length','0')
                    self.end_headers()
                    return
                end=min(end,size-1);partial=True
            length=max(0,end-start+1) if size else 0
            self.send_response(206 if partial else 200)
            self.send_header('Content-Type',mime)
            self.send_header('Content-Length',str(length if partial else size))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            if ranges: self.send_header('Accept-Ranges','bytes')
            if partial: self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
            self.end_headers()
            if head:return
            fp.seek(start)
            remaining=length if partial else size
            while remaining > 0:
                data=fp.read(min(128*1024,remaining))
                if not data:break
                try:
                    self.wfile.write(data)
                except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError):
                    return
                remaining-=len(data)

def run(manifest_file):
    mf=Path(manifest_file)
    doc=json.loads(mf.read_text(encoding='utf-8'))
    server=PlayerServer(doc)
    location = mf.with_suffix('.server.json')
    temp = location.with_suffix('.tmp')
    temp.write_text(json.dumps({'port':server.server_port,'token':server.token}),encoding='utf-8')
    os.chmod(temp,0o600)
    os.replace(temp,location)
    def watchdog():
        while True:
            time.sleep(30)
            if time.monotonic()-server.last_seen>IDLE_SECONDS:
                server.shutdown()
                return
    threading.Thread(target=watchdog,daemon=True).start()
    try: server.serve_forever(poll_interval=.5)
    finally:
        server.server_close()
        server.executor.shutdown(wait=False,cancel_futures=True)
        location.unlink(missing_ok=True)

if __name__ == '__main__':
    run(sys.argv[1])

