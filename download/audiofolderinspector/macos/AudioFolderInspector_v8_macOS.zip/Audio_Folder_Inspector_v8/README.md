# Audio Folder Inspector v8 — Full UI localization repair

## Upgrade
1. Unzip this archive.
2. Double-click `install.command`. Your previous Quick Action is backed up automatically, including installations using the original Japanese workflow name.
3. Select a Finder audio folder → **Quick Actions → Audio Folder Inspector**. Run it again to generate a **new** report: existing exported HTML does not update retroactively.

## What's changed
- Corrected partial Japanese strings leaking into the English UI (including split descriptions such as the LUFS calculation rules and folder-scope controls).
- All seven language choices are preserved: English, Japanese, French, German, Spanish, Simplified Chinese, and Korean.
- Full-paragraph technical explanations are translated per language as semantic units rather than being converted word by word.
- Folder totals, file counts, quality reasons, warning classifications, player messages, filter controls and table headings are translated consistently. Canonical measurements and file/metadata values remain unchanged.
- macOS system-language Auto mode and user preference persistence remain intact.
- Existing waveform playback, folder statistics, quality thresholds, CSV, and audio analysis are unchanged.

## Requirements and privacy
- macOS with Automator Quick Actions, Python 3 and FFmpeg/ffprobe (`brew install ffmpeg`). No virtualenv or pip packages are required.
- Everything runs locally; audio files are read-only. Reports/cache remain under `~/Library/Caches/AudioFolderInspector/` and preferences under `~/Library/Application Support/AudioFolderInspector/config.json`.
- CSV column identifiers remain English for data interchange. Audio filenames, BWF/iXML metadata, codec IDs, formats and technical units are not translated.
- The playback service stops after idle; rerun the action to listen again.

## Verification
Python and JavaScript syntax validated, generated reports analyzed against actual mixed sample-rate WAV files, and locale switching/quality reasons checked in a headless Chromium environment. macOS Finder execution and real hardware audio output cannot be verified in this environment.

## macOS distribution package
The workflow bundle is named `Audio Folder Inspector.workflow`. Setup and package documentation are in English; the report retains all seven language choices.
